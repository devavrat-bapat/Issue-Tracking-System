/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.security.Group;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Group service is used to perform database operations like retrieving and
 * updating the group of a user.
 *
 * @author bapat referenced professor's group services
 */
@Named
@Stateless
public class GroupService extends AbstractService<Group> {

    private static final Logger LOG = Logger.getLogger(GroupService.class.getName());

    /**
     *default
     */
    public GroupService() {
        super(Group.class);
    }

    /**
     *find all groups
     * @return
     */
    @Override
    public List<Group> findAll() {
        LOG.info("Inside Group services -> find All ");
        return em.createNamedQuery("Group.findAll", entityClass).getResultList();
    }

    /**
     * find group EMP_GROUP - employee
     *
     * @param name
     * @return
     */
    public Group findDefaultGroup(String name) {
        return em.createNamedQuery("Group.findDefaultGroup", entityClass).setParameter("name", name).getSingleResult();
    }

    /**
     * find group MGR_GROUP - manager
     *
     * @return
     */
    public Group findManagerGroup() {
        return em.createNamedQuery("Group.findManagerGroup", entityClass).getSingleResult();
    }

}
