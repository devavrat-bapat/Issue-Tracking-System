/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * A team can be created by Admin or a Manager. A team can consist of one or
 * more members. Manager of the team is by default a member of the team.
 *
 * @author bapat
 */
@Entity
@NamedQuery(name = "Team.findByName", query = "SELECT t from Team t where t.name = :name")
@NamedQuery(name = "Team.findAll", query = "SELECT t from Team t")
@NamedQuery(name = "Team.findById", query = "SELECT t from Team t where t.id = :id")
@NamedQuery(name = "Team.findByMember", query = "SELECT t from Team t where t.id = :id")
@NamedQuery(name = "Team.findByTeamMember", query = "SELECT t from Team t where t.id = :id")
@NamedQuery(name = "Team.findTeamsByMember", query = "SELECT t from Team t where t.emp = :employee")
@NamedQuery(name = "Team.findByTeamManager", query = "SELECT t from Team t where t.manager = :manager")
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String name;

    @Transient
    private Long managerId;

    @Version
    private Long version;

    private LocalDateTime lastUpdatedTime;
    private LocalDateTime createdTime;
    private static final Logger LOG = Logger.getLogger(Team.class.getName());

    @NotNull
    private Employee manager;

    /**
     * Get the value of manager
     *
     * @return the value of manager
     */
    public Employee getManager() {
        LOG.info("Inside getManager()");
        if (this.manager != null) {
            return manager;
        }
        return null;
    }

    /**
     * Set the value of manager
     *
     * @param manager new value of manager
     */
    public void setManager(Employee manager) {
        if (manager != null) {
            LOG.info("Inside setManager" + manager.getId());
            this.manager = manager;
            this.managerId = manager.getId();
        }
    }

    @PrePersist
    private void prePersists() {
        createdTime = LocalDateTime.now();
        lastUpdatedTime = LocalDateTime.now();

    }

    @PreUpdate
    private void preUpdate() {
        lastUpdatedTime = LocalDateTime.now();

    }

    /**
     * Constructor used to create new teams
     *
     * @param name
     * @param manager
     */
    public Team(String name, Employee manager) {
        LOG.info("Inside Team constructor : Team name =" + name + "manager id =" + manager.getId());
        this.name = name;
        this.manager = manager;
        this.managerId = manager.getId();
    }

    @OneToMany(mappedBy = "team")
    private List<Ticket> tickets = new ArrayList<>();

    @ManyToMany(mappedBy = "teams")
    private List<Employee> emp = new ArrayList<>();

    @OneToMany(mappedBy = "ticketDispatchTo")
    private List<Ticket> ticketsDispatched = new ArrayList<>();

    /**
     * Get the value of tickets List of all tickets created by members of this
     * team
     *
     * @return the value of tickets
     */
    public List<Ticket> getTickets() {
        return tickets;
    }

    /**
     * List of all tickets Sent to this team by some other teams
     *
     * @return
     */
    public List<Ticket> getTicketsDispatched() {
        return ticketsDispatched;
    }

    /**
     * Get the value of emp List of employees who are a part of this team
     *
     * @return the value of emp
     */
    public List<Employee> getEmp() {
        return emp;
    }

    /**
     * Set the value of emp
     *
     * @param emp new value of emp
     */
    public void setEmp(List<Employee> emp) {
        this.emp = emp;
    }

    /**
     * Add one or more new tickets to this team.
     *
     * @param tickets
     */
    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    /**
     * Set one or more tickets sent to this team.
     *
     * @param ticketsDispatched
     */
    public void setTicketsDispatched(List<Ticket> ticketsDispatched) {
        this.ticketsDispatched = ticketsDispatched;
    }

    /**
     * Get the value of managerId. This is a transient object. Not stored in the
     * database.
     *
     * @return the value of managerId
     */
    public Long getManagerId() {
        return managerId;
    }

    /**
     * Set the value of managerId This is a transient object. Not stored in the
     * database.
     *
     * @param managerId new value of managerId
     */
    public void setManagerId(Long managerId) {
        LOG.info("Inside Team-> setManagerID" + managerId);
        this.managerId = managerId;
    }

    /**
     * Get the value of team name
     *
     * @return the value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the value of team name
     *
     * @param name new value of name
     */
    public void setName(String name) {
        LOG.info("Inside Team->setName() " + name);
        this.name = name;
    }

    /**
     * Default constructor
     */
    public Team() {
    }

    /**
     * retrieve auto-generated value for the team in database It is the primary
     * key
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * Set the auto-generated value for team in database It is the primary key
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Incremented by 1 every time a team is updated
     *
     * @return
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Set the value of managerId Incremented by 1 every time a team is updated
     *
     * @param version
     */
    public void setVersion(Long version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "Team{" + "id=" + id + ", name=" + name + ", managerId=" + managerId + ", version=" + version + ", lastUpdatedTime=" + lastUpdatedTime + ", createdTime=" + createdTime + '}';
    }

    @Override
    public boolean equals(Object object) {
        return (object instanceof Team) && (id != null)
                ? id.equals(((Team) object).id)
                : (object == this);
    }

    /**
     * Add a ticket when created by an employee who is part of this team, on
     * behalf of this team.
     *
     * Below method is used to maintain the PK-FK One to many relationship
     * between Team and Ticket
     *
     * @param ticket
     */
    public void addTicketsCreated(Ticket ticket) {

        if (!this.tickets.contains(ticket)) {
            this.tickets.add(ticket);
        }
    }

    /**
     * Add a ticket when dispatched by an employee who believes this is the
     * right team to solve the ticket. behalf of this team.
     *
     * Below method is used to maintain the PK-FK One to many relationship
     * between Team and Ticket
     *
     * @param ticket
     */
    public void addTicketsDispatched(Ticket ticket) {

        if (!this.ticketsDispatched.contains(ticket)) {
            this.ticketsDispatched.add(ticket);
        }
    }

    /**
     * Delete ticket created so as to remove the team FK from ticket table
     *
     * @param t
     */
    public void removeTicketsCreated(Ticket t) {
        if (this.tickets.contains(t)) {
            this.tickets.remove(t);
        }
    }

    /**
     * Delete ticket dispatched so as to remove the team FK from ticket table
     *
     * @param t
     */
    public void removeTicketsDispatched(Ticket t) {
        LOG.info("Inside remove tickets dispatched to");
        if (this.ticketsDispatched.contains(t)) {
            this.ticketsDispatched.remove(t);
        }
    }

    /**
     *Remove manager from the team. This might occur when a manager leaves the organization or he is just moved on to some other team.
     * @param e
     */
    public void removeManager(Employee e) {
        LOG.info("Inside remove team " + this.name + " Manager " + e.getId());

        if (this.manager.getId() != null && this.manager.getId().equals(e.getId())) {
            LOG.info("This manager is " + this.manager.getFirstName() + " emp sent is " + e.getFirstName());
            this.manager = null;
        }
    }
}
