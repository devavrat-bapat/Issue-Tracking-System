/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

/**
 *
 *
 * TicketStatusUpdate is the most critical entity class of this application. It
 * stores information about all the tickets and all the employees-teams updated
 * it.
 *
 * Suppose team A raises a ticket and dispatches is to team B. Team B is
 * expected to read the information in the ticket carefully and then act upon
 * it.
 *
 * Once team B acts upon it, if they think that Team C also needs to be
 * involved, the ticket will be dispatched to Team C with an update from Team B.
 * So now, the ticket has information provided by Team A and Team B.
 *
 * This entity will store information about each ticket just like logs and is
 * very crucial for multiples team/employees to collaborate on same ticket.
 *
 * @author bapat
 */
@Entity
@NamedQuery(name = "TicketStatusUpdate.findByTicketId", query = "SELECT t from TicketStatusUpdate t where t.ticket = :ticket")
@NamedQuery(name = "TicketStatusUpdate.findAll", query = "SELECT t from TicketStatusUpdate t")
public class TicketStatusUpdate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Ticket ticket;

    private String ticketTitle;

    private String ticketMessage;

    private String ticketType;

    private String ticketDispatchTo;

    private String ticketCreatedOn;

    private String ticketResolveByDate;

    private String ticketPriority;

    private String ticketStatus;

    private String emp;

    private String team;

    private String lastUpdatedTime;

    private static final Logger LOG = Logger.getLogger(TicketStatusUpdate.class.getName());

    /**
     * default constructor
     */
    public TicketStatusUpdate() {
    }

    /**
     * retrieve system generated id - primary key
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * set system generated id - primary key
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Retrieve information of a ticket.
     *
     * @return
     */
    public Ticket getTicket() {
        return ticket;
    }

    /**
     * set information of a ticket.
     *
     *
     * @param ticket
     */
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     * get information of a ticket title.
     *
     * @return
     */
    public String getTicketTitle() {
        return ticketTitle;
    }

    /**
     * set information of a ticket title.
     *
     * @param ticketTitle
     */
    public void setTicketTitle(String ticketTitle) {
        this.ticketTitle = ticketTitle;
    }

    /**
     * get information of a ticket type.
     *
     * @return
     */
    public String getTicketType() {
        return ticketType;
    }

    /**
     * set information of a ticket type.
     *
     * @param ticketType
     */
    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    /**
     * get information of a team the ticket is dispatched to.
     *
     * @return
     */
    public String getTicketDispatchTo() {
        return ticketDispatchTo;
    }

    /**
     * set information of a team the ticket is dispatched to.
     *
     * @param ticketDispatchTo
     */
    public void setTicketDispatchTo(String ticketDispatchTo) {
        this.ticketDispatchTo = ticketDispatchTo;
    }

    /**
     * get information of a ticket date it was created
     *
     * @return
     */
    public String getTicketCreatedOn() {
        return ticketCreatedOn;
    }

    /**
     * set information of a ticket date it was created
     *
     * @param ticketCreatedOn
     */
    public void setTicketCreatedOn(String ticketCreatedOn) {
        this.ticketCreatedOn = ticketCreatedOn;
    }

    /**
     * get information of a ticket date it is supposed to be resolved
     *
     * @return
     */
    public String getTicketResolveByDate() {
        return ticketResolveByDate;
    }

    /**
     * set information of a ticket date it was created
     *
     * @param ticketResolveByDate
     */
    public void setTicketResolveByDate(String ticketResolveByDate) {
        this.ticketResolveByDate = ticketResolveByDate;
    }

    /**
     * get information of a ticket priority
     *
     * @return
     */
    public String getTicketPriority() {
        return ticketPriority;
    }

    /**
     * set information of a ticket priority
     *
     * @param ticketPriority
     */
    public void setTicketPriority(String ticketPriority) {
        this.ticketPriority = ticketPriority;
    }

    /**
     * get information of a ticket status
     *
     * @return
     */
    public String getTicketStatus() {
        return ticketStatus;
    }

    /**
     * set information of a ticket status
     *
     * @param ticketStatus
     */
    public void setTicketStatus(String ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    /**
     * get information of a employee who created the ticket
     *
     * @return
     */
    public String getEmp() {
        return emp;
    }

    /**
     * set information of a employee who updated the ticket
     *
     * @param emp
     */
    public void setEmp(String emp) {
        this.emp = emp;
    }

    /**
     * get information of team name who updated the ticket
     *
     * @return
     */
    public String getTeam() {
        return team;
    }

    /**
     * set information of current team name
     *
     * @param team
     */
    public void setTeam(String team) {
        this.team = team;
    }

    /**
     * get information of last updated time
     *
     * @return
     */
    public String getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    /**
     * set information of last updated time
     *
     * @param lastUpdatedTime
     */
    public void setLastUpdatedTime(String lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    /**
     * get detailed information of the update provided
     *
     * @return
     */
    public String getTicketMessage() {
        return ticketMessage;
    }

    /**
     * set detailed information of the update provided
     *
     * @param ticketMessage
     */
    public void setTicketMessage(String ticketMessage) {
        this.ticketMessage = ticketMessage;
    }

    /**
     * Constructor to update ticketStatus update table with every new ticket
     * created/updated by an employee
     *
     * @param t
     */
    public TicketStatusUpdate(Ticket t) {
        if (t.getTicketTitle() != null) {
            this.ticketTitle = t.getTicketTitle();
        }

        if (t.getTicketMessage() != null) {
            this.ticketMessage = t.getTicketMessage();
        }
        if (t.getTicketCreatedOn() != null) {
            this.ticketCreatedOn = t.getTicketCreatedOn().toString();
        }

        if (t.getTicketResolveByDate() != null) {
            this.ticketResolveByDate = t.getTicketResolveByDate().toString();
        }

        if (t.getTicketType() != null) {
            this.ticketType = t.getTicketType().getLabel();
        }
        if (t.getTicketStatus() != null) {
            this.ticketStatus = t.getTicketStatus().getLabel();
        }
        if (t.getTicketPriority() != null) {
            this.ticketPriority = t.getTicketPriority().getLabel();
        }

        if (t.getEmp() != null) {
            this.emp = t.getEmp().getFirstName() + " " + t.getEmp().getLastName();
        }
        if (t.getTeam() != null) {
            this.team = t.getTeam().getName();
        }
        if (t.getTicketDispatchTo() != null) {
            this.ticketDispatchTo = t.getTicketDispatchTo().getName();
        }
        if (1 == 1) {
            this.ticket = t;
        }
        if (t.getLastUpdatedTime() != null) {
            this.lastUpdatedTime = t.getLastUpdatedTime().toString();
        }
    }

    /**
     * Constructor to update ticketStatus update table with every new ticket
     * created/ updated by an Administrator.
     *
     * @param t
     * @param admin
     */
    public TicketStatusUpdate(Ticket t, String admin) {
        LOG.info("Ticket updated by admin");
        this.emp = "Admin";

        if (t.getTicketTitle() != null) {
            this.ticketTitle = t.getTicketTitle();
        }
        if (t.getTicketMessage() != null) {
            this.ticketMessage = t.getTicketMessage();
        }
        if (t.getTicketCreatedOn() != null) {
            this.ticketCreatedOn = t.getTicketCreatedOn().toString();
        }
        if (t.getTicketResolveByDate() != null) {
            this.ticketResolveByDate = t.getTicketResolveByDate().toString();
        }
        if (t.getTicketType() != null) {
            this.ticketType = t.getTicketType().getLabel();
        }
        if (t.getTicketStatus() != null) {
            this.ticketStatus = t.getTicketStatus().getLabel();
        }
        if (t.getTicketPriority() != null) {
            this.ticketPriority = t.getTicketPriority().getLabel();
        }
        if (t.getTeam()
                != null) {
            this.team = t.getTeam().getName();
        }
        if (t.getTicketDispatchTo()
                != null) {
            this.ticketDispatchTo = t.getTicketDispatchTo().getName();
        }
        if (1 == 1) {
            this.ticket = t;
        }
        if (t.getLastUpdatedTime()
                != null) {
            this.lastUpdatedTime = t.getLastUpdatedTime().toString();
        }
    }
}
