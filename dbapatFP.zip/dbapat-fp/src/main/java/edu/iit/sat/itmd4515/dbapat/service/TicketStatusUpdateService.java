/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatusUpdate;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * This class is used to implement the create, update and remove methods from
 * the AbstractService class.
 *
 *These methods are used to update the TicketStatusUpdate table.
 * This table stores all the updates over all the tickets.
 * 
 * Pk-Fk relationship is maintained between this table and the ticket table.
 *
 * @author bapat
 */
@Named
@Stateless
public class TicketStatusUpdateService extends AbstractService<TicketStatusUpdate> {

    private static final Logger LOG = Logger.getLogger(TicketStatusUpdateService.class.getName());

    /**
     *default constructor
     */
    public TicketStatusUpdateService() {
        super(TicketStatusUpdate.class);
    }

    /**
     *Find all the updates for all tickets
     * @return
     */
    @Override
    public List<TicketStatusUpdate> findAll() {
        return em.createNamedQuery("TicketStatusUpdate.findAll", entityClass).getResultList();
    }

    /**
     *
     * Find all ticket updates for a given ticket
     * 
     * @param ticket
     * @return
     */
    public List<TicketStatusUpdate> findByTicketId(Ticket ticket) {
        return em.createNamedQuery("TicketStatusUpdate.findByTicketId", TicketStatusUpdate.class).setParameter("ticket", ticket).getResultList();

    }

}
