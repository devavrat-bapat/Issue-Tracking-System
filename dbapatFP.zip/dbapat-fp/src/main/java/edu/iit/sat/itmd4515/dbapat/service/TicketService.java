package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatusUpdate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Ticket Service extends the AbstractService. Methods in this class are used to
 * create, update and
 *
 * @author bapat
 */
@Named
@Stateless
public class TicketService extends AbstractService<Ticket> {

    private static final Logger LOG = Logger.getLogger(TicketService.class.getName());

    /**
     * default
     *
     */
    public TicketService() {
        super(Ticket.class);
    }

    /**
     * find all tickets
     *
     * @return
     */
    @Override
    public List<Ticket> findAll() {
        return em.createNamedQuery("Ticket.findAll", entityClass).getResultList();
    }

    /**
     * find tickets by team
     *
     * @param teams
     * @return
     */
    public List<Ticket> findByTeam(List<Team> teams) {
        LOG.info("Inside find By Team 1" + teams.isEmpty());
        if (!teams.isEmpty()) {
            return em.createNamedQuery("Ticket.findByTeam", Ticket.class).setParameter("team_id", teams).getResultList();
        }
        return null;
    }

    /**
     * find tickets dispatched to some team
     *
     * @param teams
     * @return
     */
    public List<Ticket> findByTeamDispatched(List<Team> teams) {
        LOG.info("Inside find By Team 2" + teams.isEmpty());
        if (!teams.isEmpty()) {
            return em.createNamedQuery("Ticket.findByTeamDispatched", Ticket.class).setParameter("team_id", teams).getResultList();
        }
        return null;

    }

    /**
     * Create a new Ticket by an Employee
     *
     * In this methods we will create a ticket, set the employee to the one who
     * raised it, set the team on the behalf of which the employee created the
     * ticket. Then set the ticket dispatch to the appropriate team mentioned in
     * the form.
     *
     *
     * @param ticket
     * @param empFromFrom
     */
    public void createAndAddTicketByEmployee(Ticket ticket, Employee empFromFrom) {
        Employee employeeInDb = em.getReference(Employee.class, empFromFrom.getId());
        Team teamCreatedTicket = em.getReference(Team.class, ticket.getTeam().getId());
        Team teamDispatchedTicket = em.getReference(Team.class, ticket.getTicketDispatchTo().getId());
        super.create(ticket);
        em.flush();
        ticket.setEmp(employeeInDb);
        employeeInDb.addTickets(ticket);
        teamCreatedTicket.addTicketsCreated(ticket);
        teamDispatchedTicket.addTicketsDispatched(ticket);
        TicketStatusUpdate tckstup = new TicketStatusUpdate(ticket);
        ticket.addTicketStatusUpdate(tckstup);
        em.merge(ticket);
        em.merge(employeeInDb);
        em.merge(teamCreatedTicket);
        em.merge(teamDispatchedTicket);
        em.persist(tckstup);
    }

    /**
     * Create and add a ticket by Admin.
     *
     * An admin cannot choose an employee in the form. Instead it will be set to
     * created by Admin. You can assume that Admin can raise a ticket from any
     * team and dispatch it to any team.
     *
     * An admin can overwrite the contents of a ticket and update it anytime he
     * wants.
     *
     * @param ticket
     */
    public void createAndAddTicketByAdmin(Ticket ticket) {
        Team teamCreatedTicket = em.getReference(Team.class, ticket.getTeam().getId());
        Team teamDispatchedTicket = em.getReference(Team.class, ticket.getTicketDispatchTo().getId());
        ticket.setEmp(null);
        super.create(ticket);
        em.flush();
        teamCreatedTicket.addTicketsCreated(ticket);
        teamDispatchedTicket.addTicketsDispatched(ticket);
        TicketStatusUpdate tckstup = new TicketStatusUpdate(ticket, "Admin");
        ticket.addTicketStatusUpdate(tckstup);
        em.merge(ticket);
        em.merge(teamCreatedTicket);
        em.merge(teamDispatchedTicket);
        em.persist(tckstup);
    }

    /**
     * Update an existinf ticket by Admin. The current record in the Ticket
     * table will be updated. Also, there will be an update in the
     * ticketStatusUpdate table.
     *
     * Again, admin can create/ update any ticket created by any team. But, his
     * name will be mentioned in the employee's names
     *
     *
     *
     * @param newTicket
     */
    public void updateTicketByAdmin(Ticket newTicket) {
        boolean checkIfTicketIsUpdated = false;
        Ticket oldTicket = em.getReference(Ticket.class, newTicket.getId());

        em.flush();

        if (newTicket.getTicketTitle() != null && !newTicket.getTicketTitle().equals(oldTicket.getTicketTitle())) {
            oldTicket.setTicketTitle(newTicket.getTicketTitle());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketCreatedOn() != null && !newTicket.getTicketCreatedOn().equals(oldTicket.getTicketCreatedOn())) {
            oldTicket.setTicketCreatedOn(newTicket.getTicketCreatedOn());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketType() != null && !newTicket.getTicketType().equals(oldTicket.getTicketType())) {
            oldTicket.setTicketType(newTicket.getTicketType());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTeam() != null && !newTicket.getTeam().equals(oldTicket.getTeam())) {
            oldTicket.setTeam(newTicket.getTeam());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketDispatchTo() != null && !newTicket.getTicketDispatchTo().equals(oldTicket.getTicketDispatchTo())) {
            oldTicket.setTicketDispatchTo(newTicket.getTicketDispatchTo());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketMessage() != null && !newTicket.getTicketMessage().equals(oldTicket.getTicketMessage())) {
            oldTicket.setTicketMessage(newTicket.getTicketMessage());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketResolveByDate() != null && !newTicket.getTicketResolveByDate().equals(oldTicket.getTicketResolveByDate())) {
            oldTicket.setTicketResolveByDate(newTicket.getTicketResolveByDate());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketStatus() != null && !newTicket.getTicketStatus().equals(oldTicket.getTicketStatus())) {
            oldTicket.setTicketStatus(newTicket.getTicketStatus());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketPriority() != null && !newTicket.getTicketPriority().equals(oldTicket.getTicketPriority())) {
            oldTicket.setTicketPriority(newTicket.getTicketPriority());
            checkIfTicketIsUpdated = true;
        }
        if (checkIfTicketIsUpdated) {
            em.merge(oldTicket);
            TicketStatusUpdate tckstup = new TicketStatusUpdate(oldTicket, "Admin");
            oldTicket.addTicketStatusUpdate(tckstup);
            em.persist(tckstup);
        }
    }

    /**
     * update already created ticket. Update existing record in the ticket
     * table. Insert a new record in the ticketstatusupdate table.
     *
     * @param newTicket
     * @param newEmployee
     */
    public void updateCreatedTicket(Ticket newTicket, Employee newEmployee) {
        boolean checkIfTicketIsUpdated = false;
        Ticket oldTicket = em.getReference(Ticket.class, newTicket.getId());
        Employee oldEmployee = em.getReference(Employee.class, newEmployee.getId());

        em.flush();

        if (newTicket.getTicketMessage() != null && !newTicket.getTicketMessage().equals(oldTicket.getTicketMessage())) {
            oldTicket.setTicketMessage(newTicket.getTicketMessage());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketResolveByDate() != null && !newTicket.getTicketResolveByDate().equals(oldTicket.getTicketResolveByDate())) {
            oldTicket.setTicketResolveByDate(newTicket.getTicketResolveByDate());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketStatus() != null && !newTicket.getTicketStatus().equals(oldTicket.getTicketStatus())) {
            oldTicket.setTicketStatus(newTicket.getTicketStatus());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketPriority() != null && !newTicket.getTicketPriority().equals(oldTicket.getTicketPriority())) {
            oldTicket.setTicketPriority(newTicket.getTicketPriority());
            checkIfTicketIsUpdated = true;
        }
        if (checkIfTicketIsUpdated) {
            em.merge(oldTicket);
            TicketStatusUpdate tckstup = new TicketStatusUpdate(oldTicket);
            tckstup.setEmp(oldEmployee.getFirstName() + " " + oldEmployee.getLastName());
            oldTicket.addTicketStatusUpdate(tckstup);
            em.persist(tckstup);
        }
    }

    /**
     * Update the ticket that was dispatched to one of the employee's team.
     * Update the entry in ticket table. Add a new record inside
     * ticketstatusupdate table
     *
     *
     * @param newTicket
     * @param newEmployee
     */
    public void updateReceivedTicket(Ticket newTicket, Employee newEmployee) {
        boolean checkIfTicketIsUpdated = false;
        Ticket oldTicket = em.getReference(Ticket.class, newTicket.getId());
        Employee oldEmployee = em.getReference(Employee.class, newEmployee.getId());

        em.flush();
        if (newTicket.getTicketMessage() != null && !newTicket.getTicketMessage().equals(oldTicket.getTicketMessage())) {
            oldTicket.setTicketMessage(newTicket.getTicketMessage());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketResolveByDate() != null && !newTicket.getTicketResolveByDate().equals(oldTicket.getTicketResolveByDate())) {
            oldTicket.setTicketResolveByDate(newTicket.getTicketResolveByDate());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketStatus() != null && !newTicket.getTicketStatus().equals(oldTicket.getTicketStatus())) {
            oldTicket.setTicketStatus(newTicket.getTicketStatus());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketPriority() != null && !newTicket.getTicketPriority().equals(oldTicket.getTicketPriority())) {
            oldTicket.setTicketPriority(newTicket.getTicketPriority());
            checkIfTicketIsUpdated = true;
        }
        if (newTicket.getTicketDispatchTo() != null && !newTicket.getTicketDispatchTo().equals(oldTicket.getTicketDispatchTo())) {
            oldTicket.setTicketDispatchTo(newTicket.getTicketDispatchTo());
            checkIfTicketIsUpdated = true;
        }

        if (checkIfTicketIsUpdated) {
            em.merge(oldTicket);
            TicketStatusUpdate tckstup = new TicketStatusUpdate(oldTicket);
            tckstup.setEmp(oldEmployee.getFirstName() + " " + oldEmployee.getLastName());
            oldTicket.addTicketStatusUpdate(tckstup);
            em.persist(tckstup);
        }
    }

    /**
     * Remove a ticket from Admin controller. Only admin has the privileges to
     * delete a ticket and all its updates.
     *
     * @param ticketFromAdmin
     */
    @Override
    public void remove(Ticket ticketFromAdmin) {

        Ticket ticketFromDatabase = em.getReference(Ticket.class, ticketFromAdmin.getId());
        List<TicketStatusUpdate> ticketUpdatesToRemove = new ArrayList<>(ticketFromDatabase.getTckstup());
        ticketUpdatesToRemove.forEach((TicketStatusUpdate t) -> {
            t.getTicket().removeTicketStatusUpdate(t);
            em.remove(t);
        });
        em.remove(ticketFromDatabase);

    }

}
