/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

/**
 * Employee is an entity class. It i used to store information about an
 * employee. Every employee must have a First name, Last Name, email Id, phone
 * number, address, date of birth. An employee can have a Manager, can be
 * assigned to zero or more teams. Employee can also raise tickets on behalf of
 * the teams he is part of.
 *
 *
 * @author bapat
 */
@Entity
@NamedQuery(name = "Employee.findById", query = "SELECT e from Employee e where e.id = :id")
@NamedQuery(name = "Employee.findByFirstName", query = "SELECT e from Employee e where e.id = :id")
@NamedQuery(name = "Employee.findAll", query = "SELECT e from Employee e")
@NamedQuery(name = "Employee.findByUsername", query = "SELECT e from Employee e where e.user.userName = :username")
@NamedQuery(name = "Employee.findByManager", query = "SELECT e from Employee e where e.manager.id = :id")
@NamedQuery(name = "Employee.findByTeam", query = "SELECT e from Employee e where e.teams = :team")
@NamedQuery(name = "Employee.findAllExcept", query = "SELECT e from Employee e where e.id <> :id")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String firstName;

    @NotBlank
    private String lastName;

    @NotBlank
    private String emailId;

    @NotNull
    @NotBlank
    private String phoneNo;

    @NotBlank
    private String address;

    @NotNull
    @Past
    private LocalDate dateOfBirth;

    @Version
    private Long version;

    @OneToMany(mappedBy = "emp")
    private List<Ticket> tickets = new ArrayList<>();

    @ManyToMany
    @JoinTable(name = "EMPLOYEE_TEAMS",
            joinColumns = @JoinColumn(name = "EMPLOYEE_ID"),
            inverseJoinColumns = @JoinColumn(name = "TEAM_ID"))
    private List<Team> teams = new ArrayList<>();

    @OneToOne
    @JoinColumn(name = "manager_id")
    private Employee manager;

    @OneToOne(mappedBy = "manager")
    private Employee employee;

    private LocalDateTime lastUpdatedTime;
    private LocalDateTime createdTime;

    @OneToOne
    @JoinColumn(name = "USERNAME")
    private User user;

    private static final Logger LOG = Logger.getLogger(Employee.class.getName());

    /**
     * Returns User information. User contains username and password.
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     * Set User information. User contains username and password.
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

    @PrePersist
    private void prePersists() {
        createdTime = LocalDateTime.now();
        lastUpdatedTime = LocalDateTime.now();

    }

    @PreUpdate
    private void preUpdate() {
        lastUpdatedTime = LocalDateTime.now();

    }

    /**
     * Get the value of teams This is a list of teams that the current employee
     * is part of.
     *
     * @return the value of teams
     */
    public List<Team> getTeams() {
        return teams;
    }

    /**
     * Set the value of teams. This list of teams that an employee will become a
     * part of.
     *
     * @param teams new value of teams
     */
    public void setTeams(List<Team> teams) {
        this.teams = teams;
    }

    /**
     * Get the value of dateOfBirth. Returns birth date of current employee
     *
     * @return the value of dateOfBirth
     */
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Set the value of dateOfBirth. Birthdate of current employee
     *
     * @param dateOfBirth new value of dateOfBirth
     */
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Get the value of address. Location of the current employee
     *
     * @return the value of address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Set the value of address. Location of the current employee
     *
     * @param address new value of address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Get the value of phoneNo. Contact no of current employee
     *
     * @return the value of phoneNo
     */
    public String getPhoneNo() {
        return phoneNo;
    }

    /**
     * Set the value of phoneNo. Save the contact no of current employee
     *
     * @param phoneNo new value of phoneNo
     */
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    /**
     * Get the value of emailId. Every employee is expected to provide his/her
     * personal id here.
     *
     * @return the value of emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * Set the value of emailId
     *
     * @param emailId new value of emailId
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * Get the value of lastName
     *
     * @return the value of lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Set the value of lastName
     *
     * @param lastName new value of lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Default constructor
     */
    public Employee() {
    }

    /**
     * Retrieve auto generated id. Primary key in database
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * Set auto generated id. Primary key in database
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Get the value of firstName
     *
     * @return the value of firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Set the value of firstName
     *
     * @param firstName new value of firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Incremented by 1 every time employee is updated
     *
     * @return
     */
    public Long getVersion() {
        return version;
    }

    /**
     * Incremented by 1 every time employee is updated
     *
     * @param version
     */
    public void setVersion(Long version) {
        this.version = version;
    }

    /**
     * Stores information about all the tickets the current user has created on
     * behalf of his team
     *
     * @param ticket
     */
    public void setTickets(List<Ticket> ticket) {
        this.tickets = ticket;
    }

    /**
     * Retrieve all tickets created by an employee
     *
     * @return
     */
    public List<Ticket> getTickets() {
        return tickets;
    }

    /**
     * Constructor used to initialize an employee
     *
     * @param firstName - first name
     * @param lastName - last name
     * @param emailId - email address
     * @param phoneNo - contact number
     * @param address - location
     * @param dateOfBirth - birth date
     * @param manager - manager
     */
    public Employee(String firstName, String lastName, String emailId, String phoneNo, String address, LocalDate dateOfBirth, Employee manager) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailId = emailId;
        this.phoneNo = phoneNo;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.manager = manager;
    }

    /**
     *
     * @param firstName
     * @param lastName
     * @param emailId
     * @param phoneNo
     * @param address
     * @param dateOfBirth
     */
    public Employee(String firstName, String lastName, String emailId, String phoneNo, String address, LocalDate dateOfBirth) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailId = emailId;
        this.phoneNo = phoneNo;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
    }

    /**
     *
     * @param t
     */
    public void addTeam(Team t) {
        LOG.info("Inside Employee -> addTeam()" + t.getName());
        if (!this.teams.contains(t)) {
            LOG.info("Inside emp -> addTeam");
            this.teams.add(t);
        }
        if (!t.getEmp().contains(this)) {
            t.getEmp().add(this);
        }
    }

    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", address=" + address + ", version " + version + ", lastUpdatedTime=" + lastUpdatedTime + ", createdTime=" + createdTime + '}';
    }

    /**
     * Add a newly created ticket to the list of tickets inside Employee. Used
     * to maintain the pk-fk relationships
     *
     * @param ticket
     */
    public void addTickets(Ticket ticket) {

        if (!this.tickets.contains(ticket)) {
            this.tickets.add(ticket);
        }
    }

    /**
     * Set manager information. A manager is also essentially an employee.
     *
     * @return
     */
    public Employee getManager() {
        return manager;
    }

    /**
     * Retrieve employee information.
     *
     * @return
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     * Retrieve manager information. A manager is also essentially an employee.
     *
     * @param manager
     */
    public void setManager(Employee manager) {
        this.manager = manager;
    }

    /**
     * When a manager is changed, this method is invoked.
     *
     * @param manager
     */
    public void removeManager(Employee manager) {
        if (this.manager.equals(manager)) {
            this.manager = null;
        }
        LOG.info("removeManager exited");

    }

    /**
     * Invoked to set employees of a manager.
     *
     * @param employee
     */
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    /**
     * to override equals(). This helps to get rid of validation errors in JSF
     * select many boxes.
     *
     * @param object
     * @return
     */
    @Override
    public boolean equals(Object object) {
        return (object instanceof Employee) && (id != null)
                ? id.equals(((Employee) object).id)
                : (object == this);
    }

    /**
     * This method is used as a helper method to manage both sides of this
     * bi-directional ManyToMany relationship
     *
     * @param t
     */
    public void removeTeam(Team t) {
        LOG.info("Inside remove teams " + t.getName());
        if (this.teams.contains(t)) {
            this.teams.remove(t);
        }
        if (t.getEmp().contains(this)) {
            t.getEmp().remove(this);
        }
    }

    /**
     * This method is used to remove tickets from the list of tickets created by
     * this user. This will be invoked when deleting a ticket or an employee
     *
     * @param t
     */
    public void removeTickets(Ticket t) {
        if (this.tickets.contains(t)) {
            LOG.info("Removing emp " + id + "from ticket " + t.getId());
            this.tickets.remove(t);

            LOG.info("Checking tickets :" + this.tickets.toString());
        }
        if (t.getEmp().id.equals(this.id)) {
            LOG.info("Same value found" + t.getEmp().firstName);
            t.setEmp(null);
        }
    }
}
