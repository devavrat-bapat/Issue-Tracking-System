/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatusUpdate;
import edu.iit.sat.itmd4515.dbapat.domain.security.Group;
import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Employee service is the service layer class for all the database operations
 * triggered from Employee Controller. Operations are meant for Employees, but
 * the methods might touch other entities like Team and Ticket due to the One To
 * Many relationships.
 *
 *
 * @author bapat
 */
@Named
@Stateless
public class EmployeeService {

    @PersistenceContext(name = "itmd4515PU")
    private EntityManager em;
    private static final Logger LOG = Logger.getLogger(EmployeeService.class.getName());
    @EJB
    private UserService userSvc;

    @EJB
    GroupService grpSvc;

    /**
     * Default constructor
     */
    public EmployeeService() {
    }

    /**
     * method to create a new employee
     *
     * @param e
     */
    public void create(Employee e) {
        em.persist(e);
    }

    /**
     * method to create an employee
     *
     * @param e
     * @return
     */
    public Employee createEmployee(Employee e) {
        em.persist(e);
        em.flush();
        return e;
    }

    /**
     * method to update an existing employee.
     *
     * We get the referece of the existing employee from database. Then we set
     * the updated values of an Employee. Then we check if the new user has the
     * same manager. If it is changed we set a new Manager.
     *
     * @param empFromUserForm
     *
     *
     * @param g Group g is sent , only when a user is to be assigned a new
     * group.
     *
     *
     * @param u We need to access the User so as to retrieve the groups that are
     * already assigned
     */
    public void update(Employee empFromUserForm, Group g, User u) {

        try {

            LOG.info("Inside  Employee Service ->  update()  ");

            Employee empInDatabase = em.getReference(Employee.class, empFromUserForm.getId());
            empInDatabase.setFirstName(empFromUserForm.getFirstName());
            empInDatabase.setLastName(empFromUserForm.getLastName());
            empInDatabase.setDateOfBirth(empFromUserForm.getDateOfBirth());
            empInDatabase.setEmailId(empFromUserForm.getEmailId());
            empInDatabase.setPhoneNo(empFromUserForm.getPhoneNo());
            empInDatabase.setAddress(empFromUserForm.getAddress());
            empInDatabase.getUser().setPassword(u.getPassword());

            if (empFromUserForm.getManager() != null) {
                empInDatabase.setManager(empFromUserForm.getManager());
                Employee manager = em.getReference(Employee.class, empFromUserForm.getManager().getId());
                Group mgrGroup = grpSvc.findManagerGroup();
                User emp2 = userSvc.findByUsername(manager.getUser().getUserName());
                emp2.setPassword("newManager123");
                List<Group> g1 = new ArrayList<>(emp2.getGroups());
                if (!g1.contains(mgrGroup)) {
                    emp2.addGroup(mgrGroup);
                }
                grpSvc.update(mgrGroup);
                userSvc.update(emp2);
                em.merge(manager);
            }
            em.merge(empInDatabase);
        } catch (Exception e) {
            LOG.info("Inside  Employee Service ->  update  " + e.getMessage());
        }
    }

    /**
     * Update an existing employee without changing the roles
     *
     * @param empFromUserForm
     */
    public void update(Employee empFromUserForm) {
        try {
            LOG.info("Entered EmployeeService -> update");
            Employee empInDatabase = em.getReference(Employee.class, empFromUserForm.getId());

            empInDatabase.setFirstName(empFromUserForm.getFirstName());
            empInDatabase.setLastName(empFromUserForm.getLastName());
            empInDatabase.setDateOfBirth(empFromUserForm.getDateOfBirth());
            empInDatabase.setEmailId(empFromUserForm.getEmailId());
            empInDatabase.setPhoneNo(empFromUserForm.getPhoneNo());
            empInDatabase.setAddress(empFromUserForm.getAddress());

            if (empFromUserForm.getManager() != null) {
                empInDatabase.setManager(empFromUserForm.getManager());
            }
            em.merge(empInDatabase);
            LOG.info("Completed EmployeeService -> update");
        } catch (Exception e) {
            LOG.info("Inside  Employee Service ->  uodate()  " + e.getMessage());
        }
    }

    /**
     * Delete an employee We need to delete the tickets raised by the employee.
     * We also need to delete all the updates provided on the ticket.
     *
     * @param empFromUserForm
     */
    public void remove(Employee empFromUserForm) {

        try {
            LOG.info("Entered EmployeeService -> remove");
            Employee empFromDatabase = em.getReference(Employee.class, empFromUserForm.getId());

            List<Ticket> ticketsCreatedToRemove = new ArrayList<>(empFromDatabase.getTickets());

            ticketsCreatedToRemove.forEach((Ticket t) -> {
                List<TicketStatusUpdate> ticketUpdatesToRemove = new ArrayList<>(t.getTckstup());

                ticketUpdatesToRemove.forEach((TicketStatusUpdate tu) -> {
                    tu.getTicket().removeTicketStatusUpdate(tu);
                    em.remove(tu);
                });

                t.getTeam().removeTicketsCreated(t);
                t.getEmp().removeTickets(t);
                t.getTicketDispatchTo().removeTicketsDispatched(t);
                em.remove(t);
            });

            List<Team> teams = new ArrayList<>(empFromDatabase.getTeams());
            teams.forEach((Team t) -> {

                if (t.getManager() != null) {
                    t.removeManager(empFromDatabase);
                    em.merge(t);
                }
                empFromDatabase.removeTeam(t);
                em.merge(t);
                em.merge(empFromDatabase);
            });

            List<Employee> employees = new ArrayList<>(findByManager(empFromDatabase.getId()));
            employees.forEach((Employee e) -> {

                e.removeManager(empFromDatabase);
                em.merge(empFromDatabase);
                em.merge(e);
            });

            if (empFromDatabase.getUser() != null) {
                em.remove(empFromDatabase.getUser());
            }
            em.remove(empFromDatabase);
            LOG.info("Completed EmployeeService -> remove");
        } catch (Exception e) {
            LOG.info("Inside  Employee Service ->  remove()  " + e.getMessage());
        }

    }

    /**
     *
     * @param id
     * @return
     */
    public Employee find(Long id) {

        LOG.info("Inside Employee service find() id = " + id + "Found :" + em.find(Employee.class, id));
        return em.find(Employee.class, id);
    }

    /**
     *
     * @param id
     * @return
     */
    public List<Employee> findById(Long id) {
        LOG.info("Inside Employee service findById() " + id);
        return em.createNamedQuery("Employee.findById", Employee.class).setParameter("id", id).getResultList();
    }

    /**
     *
     * @return
     */
    public List<Employee> findAll() {
        LOG.info("Inside  Employee Service ->  findAll() ");
        return em.createNamedQuery("Employee.findAll", Employee.class).getResultList();
    }

    /**
     *
     * @param username
     * @return
     */
    public Employee findByUsername(String username) {
        LOG.info("Inside  Employee Service ->  findByUsername ");
        return em.createNamedQuery("Employee.findByUsername", Employee.class).setParameter("username", username).getSingleResult();
    }

    /**
     *
     * @param username
     * @return
     */
    public Employee findByUsernames(String username) {
        LOG.info("Inside  Employee Service ->  findByUsernames()  ");
        return em.createNamedQuery("Employee.findByUsername", Employee.class).setParameter("username", username).getSingleResult();
    }

    /**
     *
     * @param id
     * @return
     */
    public Employee findByTicketByTeam(Long id) {
        LOG.info("Inside  Employee Service ->  findByTicketTeam()  ");
        Employee e = em.createNamedQuery("Employee.findByTicketByTeam", Employee.class).setParameter("id", id).getSingleResult();
        return e;
    }

    /**
     *
     * @param id
     * @return
     */
    public List<Employee> findByManager(Long id) {
        LOG.info("Inside  Employee Service ->  findByManager()  ");
        return em.createNamedQuery("Employee.findByManager", Employee.class).setParameter("id", id).getResultList();
    }

    /**
     *
     * @param team
     * @return
     */
    public List<Employee> findByTeam(Team team) {
        LOG.info("Inside Employee service findByTeam() " + team.getId());
        return em.createNamedQuery("Employee.findByTeam", Employee.class).setParameter("team", team).getResultList();
    }

    /**
     *
     * @param id
     * @return
     */
    public List<Employee> findAllExcept(Long id) {
        LOG.info("Inside  Employee Service ->  findAllExcept()  ");
        return em.createNamedQuery("Employee.findAllExcept", Employee.class).setParameter("id", id).getResultList();
    }

    /**
     * Create an employee from Admin An admin can select any employee as an
     * administrator. But, once the employee role is changed, we are forced to
     * change/reset the password.
     *
     *
     * @param employeeFromAdminForm
     * @param group
     * @param user
     */
    public void createAndAddEmployeeByAdmin(Employee employeeFromAdminForm, Group group, User user) {

        try {
            LOG.info("Inside  Employee Service ->  createAndAddEmployeeByAdmin()  ");

            em.persist(user);
            user.addGroup(group);
            employeeFromAdminForm.setUser(user);

            em.persist(employeeFromAdminForm);
            em.flush();

            if (employeeFromAdminForm.getManager() != null) {

                Employee manager = em.getReference(Employee.class, employeeFromAdminForm.getManager().getId());

                Group mgrGroup = grpSvc.findManagerGroup();

                User emp2 = userSvc.findByUsername(manager.getUser().getUserName());
                emp2.setPassword("newManager123");

                List<Group> g1 = new ArrayList<>(emp2.getGroups());

                if (!g1.contains(mgrGroup)) {
                    emp2.addGroup(mgrGroup);
                }

                grpSvc.update(mgrGroup);
                userSvc.update(emp2);
                em.merge(manager);

            }
        } catch (Exception e) {
            LOG.info("Inside  Employee Service ->  createAndAddEmployeeByAdmin() \n " + e.getMessage());
        }
    }
}
