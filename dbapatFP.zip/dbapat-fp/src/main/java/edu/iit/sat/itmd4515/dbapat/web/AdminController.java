/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketPriority;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatus;
import edu.iit.sat.itmd4515.dbapat.domain.TicketType;
import edu.iit.sat.itmd4515.dbapat.domain.security.Group;
import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import edu.iit.sat.itmd4515.dbapat.service.EmployeeService;
import edu.iit.sat.itmd4515.dbapat.service.GroupService;
import edu.iit.sat.itmd4515.dbapat.service.TeamService;
import edu.iit.sat.itmd4515.dbapat.service.TicketService;
import edu.iit.sat.itmd4515.dbapat.service.UserService;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 * Referenced from Instructor example
 *
 *
 * Admin Controller is the Middle layer that connects to both the view and the
 * database (through services)
 *
 * All the CRUD operations for Admin are triggered from this controller
 *
 * @author bapat
 */
@Named
@RequestScoped
public class AdminController {

    private static final Logger LOG = Logger.getLogger(AdminController.class.getName());

    @EJB
    private TeamService teamSvc;

    private Team team;

    @EJB
    private EmployeeService empSvc;

    private Employee employee;
    @EJB
    private UserService userSvc;

    private User user;

    @EJB
    private GroupService groupSvc;

    private Group group;

    @EJB
    private TicketService tckSvc;

    private Ticket ticket;

    private String username;
    private final String password = "newUser123";

    /**
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @return
     */
    public Ticket getTicket() {
        return ticket;
    }

    /**
     *
     * @param ticket
     */
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     *
     * @return
     */
    public TicketType[] getTicketTypes() {
        return TicketType.values();
    }

    /**
     *
     * @return
     */
    public TicketPriority[] getTicketPrioritys() {
        return TicketPriority.values();
    }

    /**
     *
     * @return
     */
    public TicketStatus[] getTicketStatuses() {
        return TicketStatus.values();
    }

    /**
     * default
     */
    public AdminController() {
    }

    @PostConstruct
    private void postConstruct() {
        team = new Team();
        employee = new Employee();
        group = new Group();
        user = new User();
        ticket = new Ticket();
    }

    /**
     *
     * @return
     */
    public Group getGroup() {
        return group;
    }

    /**
     *
     * @param group
     */
    public void setGroup(Group group) {
        this.group = group;
    }

    /**
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Referenced from Instructor example
     *
     * @param t
     * @return
     */
    public String formatEmployeesAsString(Team t) {
        List<String> empNames = new ArrayList<>();

        for (Employee e : t.getEmp()) {
            empNames.add(e.getFirstName());
        }

        return String.join(",", empNames);
    }

    /**
     *
     * @return
     */
    public Team getTeam() {
        return team;
    }

    /**
     * Set value of team
     *
     * @param team
     */
    public void setTeam(Team team) {
        this.team = team;
    }

    /**
     * Preparing to view a team
     *
     * @param t
     * @return
     */
    public String prepareViewTeam(Team t) {
        LOG.info("Inside  AdminController ->   prepare view Team ()  ");
        this.team = t;
        return "/admin/viewTeam.xhtml";
    }

    /**
     * Preparing to view a team
     *
     * @param t
     * @return
     */
    public String prepareEditTeam(Team t) {
        LOG.info("Inside  AdminController ->   prepare edit Team ()  ");
        this.team = t;
        return "/admin/editTeam.xhtml";
    }

    /**
     * Preparing to create a team
     *
     * @return
     */
    public String prepareCreateTeam() {
        LOG.info("Inside  AdminController ->   prepare create Team ()  ");
        this.team = new Team();
        return "/admin/editTeam.xhtml";
    }

    /**
     * Create/Update a team
     *
     * @return
     */
    public String doSaveTeam() {
        LOG.info("Inside  AdminController ->  do save Team ()  ");

        if (this.team.getId() != null) {
            LOG.info("Inside  AdminController ->   prepare view Team () update team  ");
            teamSvc.update(team);
        } else {
            LOG.info("Inside  AdminController ->   prepare view Team () create new team ");
            teamSvc.createAndAddTeamByAdmin(team);
        }
        return "/admin/teamsManage.xhtml?faces-redirect=true";
    }

    /**
     *
     * Delete a team
     *
     * @param t
     * @return
     */
    public String doDeleteTeam(Team t) {
        LOG.info("Inside  AdminController ->   delete Team ()  ");
        teamSvc.remove(t);
        return "/admin/teamsManage.xhtml?faces-redirect=true";

    }

    /**
     *
     * @return
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     *
     * @param employee
     */
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    /**
     * Preparing to view an employee
     *
     * @param e
     * @return
     */
    public String prepareViewEmployee(Employee e) {
        LOG.info("Inside Admin prepareViewEmployee");
        this.employee = e;
        return "/admin/viewEmployee.xhtml";
    }

    /**
     * Preparing to edit an employee
     *
     * @param e
     * @return
     */
    public String prepareEditEmployee(Employee e) {
        LOG.info("Inside Admin prepareEditEmployee");
        this.employee = e;
        return "/admin/editEmployee.xhtml";
    }

    /**
     * Preparing to create an employee
     *
     * @return
     */
    public String prepareCreateEmployee() {
        LOG.info("Inside Admin prepareCreateEmployee");
        this.employee = new Employee();
        return "/admin/editEmployee.xhtml";
    }

    /**
     * If employee already exists ? update it. If not, then create a new
     * Employee. Assign a manager as filled in the form.
     *
     * @return
     */
    public String doSaveEmployee() {
        LOG.info("Inside  AdminController ->   save employee ()  ");
        if (this.employee.getId() != null) {
            Group group = groupSvc.findDefaultGroup("EMP_GROUP");
            user = new User(username, password, true);
            empSvc.update(employee, group, user);
        } else {
            Group group = groupSvc.findDefaultGroup("EMP_GROUP");

            this.username = "" + this.employee.getFirstName()
                    + this.employee.getLastName()
                    + "" + this.employee.getDateOfBirth().getMonthValue()
                    + "" + this.employee.getDateOfBirth().getDayOfMonth()
                    + "" + this.employee.getDateOfBirth().getYear();

            user = new User(username, password, true);
            empSvc.createAndAddEmployeeByAdmin(employee, group, user);
        }
        return "/admin/employeesManage.xhtml?faces-redirect=true";

    }

    /**
     * Delete an employee. Remove all the references from tickets, remove all
     * the references from Teams, ticket updates and if he is the manager of any
     * other employee
     *
     * @param e
     * @return
     */
    public String doDeleteEmployee(Employee e) {
        LOG.info("Inside doDeleteEmp ()");
        empSvc.remove(e);
        return "/admin/employeesManage.xhtml?faces-redirect=true";

    }

    /**
     * Preparing to view a ticket
     *
     * @param t
     * @return
     */
    public String prepareViewTicket(Ticket t) {
        LOG.info("Inside Admin viewTicket" + t.getTicketTitle());
        this.ticket = t;
        return "/admin/viewTicket.xhtml";
    }

    /**
     * Preparing to update a ticket
     *
     * @param t
     * @return
     */
    public String prepareUpdateTicket(Ticket t) {
        LOG.info("Inside Admin prepare Update ticket" + t.getTicketTitle());
        LOG.info("Inside Admin prepare Update ticket" + t.getId());

        this.ticket = t;

        return "/admin/editTicket.xhtml";
    }

    /**
     * Preparing to create a new ticket.
     *
     * @return
     */
    public String prepareCreateTicket() {
        LOG.info("Inside  AdminController ->   prepare create ticket ()  ");
        this.ticket = new Ticket();
        return "/admin/editTicket.xhtml";
    }

    /**
     * Delete the ticket selected.
     *
     * Also, delete all the references of the ticket from ticketStatusUpdate,
     * employee and teams tables.
     *
     * @param t
     * @return
     */
    public String doDeleteTicket(Ticket t) {
        LOG.info("Inside doDeleteTicket  " + t.toString());
        tckSvc.remove(t);
        return "/admin/ticketsManage.xhtml?faces-redirect=true";

    }

    /**
     * Check if ticket is already created. Yes ? then Update it. No ? Then
     * create a new one.
     *
     * @return
     */
    public String doSaveTicket() {
        LOG.info("Inside  AdminController ->   save ticket ()  ");
        if (this.ticket.getId() != null) {
            tckSvc.updateTicketByAdmin(ticket);
        } else {
            tckSvc.createAndAddTicketByAdmin(ticket);
        }
        return "/admin/ticketsManage.xhtml?faces-redirect=true";
    }
}
