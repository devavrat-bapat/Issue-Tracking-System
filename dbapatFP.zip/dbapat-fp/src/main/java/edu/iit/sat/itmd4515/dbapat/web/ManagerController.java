/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import edu.iit.sat.itmd4515.dbapat.service.EmployeeService;
import edu.iit.sat.itmd4515.dbapat.service.TeamService;
import edu.iit.sat.itmd4515.dbapat.service.TicketService;
import edu.iit.sat.itmd4515.dbapat.service.UserService;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * Manager Controller is the middle layer between the view and the Database
 * operations (Service layer)
 *
 *
 * @author bapat
 */
@Named
@RequestScoped
public class ManagerController {

    private static final Logger LOG = Logger.getLogger(ManagerController.class.getName());

    @EJB
    private EmployeeService empSvc;

    @EJB
    private TeamService teamSvc;

    private Employee employee;

    private Team team;

    @EJB
    private TicketService tckSvc;

    private Ticket ticket;

    @Inject
    LoginController loginController;
    @EJB
    private UserService userSvc;

    private User user;
    private String username;
    private String password;

    @PostConstruct
    private void postConstruct() {
        LOG.info("EmployeeController running postConstruct()");
        employee = empSvc.findByUsername(loginController.getRemoteUser());
        team = new Team();
    }

    /**
     *
     * @return
     */
    public Team getTeam() {
        return team;
    }

    /**
     *
     * @param team
     */
    public void setTeam(Team team) {
        this.team = team;
    }

    /**
     *
     * @return
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     *
     * @param employee
     */
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    /**
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * prepare view team
     *
     * @param t
     * @return
     */
    public String prepareViewTeam(Team t) {
        LOG.info("Emp prepareViewTeam   " + t.toString());
        this.team = t;
        return "/mgr/viewTeam.xhtml";
    }

    /**
     * prepare edit team
     *
     * @param t
     * @return
     */
    public String prepareEditTeam(Team t) {
        LOG.info("Emp prepareEditTeam   " + t.getName());
        this.team = t;
        return "/mgr/editTeam.xhtml";
    }

    /**
     * prepare create team
     *
     * @return
     */
    public String prepareCreateTeam() {
        LOG.info("mgr prepareCreateTeam");
        this.team = new Team();
        return "/mgr/editTeam.xhtml";
    }

    /**
     * If team already exists ? update it.
     *
     * If team doesn't exist, create new.
     *
     *
     * @return
     */
    public String doSaveTeam() {
  LOG.info("Inside  ManagerController ->  saveTeam()  ");
        if (this.team.getId() != null) {
            this.team.setManager(employee);
            teamSvc.update(team);
        } else {
            teamSvc.createAndAddTeamByManager(team, employee);
        }
        return "/mgr/teamsManage.xhtml?faces-redirect=true";

    }

    /**
     *
     * if team already exists, edit team
     *
     * @param t
     * @return
     */
    public String doEditTeam(Team t) {
        LOG.info("Inside doEditTeam  " + t.toString());
        return "/welcome.xhtml";
    }

    /**
     * Delete team if exists.
     *
     * Delete all the references of the team from tickets, ticket updates.
     *
     * Remove all employees that are part of the team.
     *
     *
     * @param t
     * @return
     */
    public String doDeleteTeam(Team t) {
          LOG.info("Inside  ManagerCOntroller ->  delete team()  ");
        teamSvc.remove(t);
        return "/mgr/teamsManage.xhtml?faces-redirect=true";
    }

    /**
     * prepare view Employee
     *
     * @param e
     * @return
     */
    public String prepareViewEmployee(Employee e) {
        this.employee = e;
        return "/mgr/viewEmployee.xhtml";
    }

    /**
     * prepare edit employee
     *
     * @param e
     * @return
     */
    public String prepareEditEmployee(Employee e) {
            LOG.info("Inside  ManagerCOntroller ->  prepare edit employee()  ");
        this.employee = e;
        return "/mgr/editEmployee.xhtml";
    }

    /**
     * prepare create new employee
     *
     * @return
     */
    public String prepareCreateEmployee() {
            LOG.info("Inside  ManagerCOntroller ->  prepare create employee()  ");
        this.team = new Team();
        return "/mgr/editEmployee.xhtml";
    }

    /**
     * Update employee if already exists.
     *
     * @return
     */
    public String doSaveEmployee() {

        if (this.employee.getId() != null) {
            LOG.info("doSave Preparing to call an update in the service layer with " + this.employee.toString());
            empSvc.update(employee);
        }

        return "/mgr/employeesManage.xhtml?faces-redirect=true";
    }

    /**
     * prepare view Ticket
     *
     * @param t
     * @return
     */
    public String prepareViewTicket(Ticket t) {
            LOG.info("Inside  ManagerCOntroller ->  prepare view ticket()  ");
        this.ticket = t;
        return "/mgr/viewTicket.xhtml";
    }
}
