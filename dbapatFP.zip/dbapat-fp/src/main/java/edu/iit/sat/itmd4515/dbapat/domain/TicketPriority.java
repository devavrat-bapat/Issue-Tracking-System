/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

/**
 *
 * @author bapat
 */
public enum TicketPriority {

    /**
     * Highest priority of a ticket. Helps employees prioritize issues on a
     * day-to-day basis.
     */
    P1("Priority 1"),
    /**
     * Second Highest priority of a ticket. Helps employees prioritize issues
     * on a day-to-day basis.
     */
    P2("Priority 2"),
    /**
     * Third Highest priority of a ticket. Helps employees prioritize issues on a
     * day-to-day basis.
     */
    P3("Priority 3"),
    /**
     * Fourth Highest priority of a ticket. Helps employees prioritize issues on a
     * day-to-day basis.
     *
     */
    P4("Priority 4"),
    /**
     * Lowest priority of a ticket. Helps employees prioritize issues on a
     * day-to-day basis.
     */
    P5("Priority 5");

    private String label;

    private TicketPriority(String label) {
        this.label = label;
    }

    /**
     *get the lable name
     * @return
     */
    public String getLabel() {
        return label;
    }
}
