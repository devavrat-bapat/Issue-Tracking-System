/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.service.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.SecurityContext;
import javax.security.enterprise.authentication.mechanism.http.AuthenticationParameters;
import javax.security.enterprise.credential.Credential;
import javax.security.enterprise.credential.Password;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;

/**
 *
 * Referenced from Instructor example
 *
 * @author bapat referenced professor's login controller
 */
@Named
@RequestScoped
public class LoginController {

    private static final Logger LOG = Logger.getLogger(LoginController.class.getName());

    @NotBlank(message = "Please enter a username")
    private String username;
    @NotBlank(message = "Please enter a password")
    private String password;

    private String newPassword;

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;

    @EJB
    UserService userSvc;

    /**
     *
     */
    public LoginController() {
    }

    /**
     *
     * @return
     */
    public String getRemoteUser() {
        return facesContext.getExternalContext().getRemoteUser();
    }

    /**
     *
     * @return
     */
    public String doLogin() {
        LOG.info("inside LoginController -> doLogin()");
        Credential credential = new UsernamePasswordCredential(username, new Password(password));

        AuthenticationStatus status = securityContext.authenticate(
                (HttpServletRequest) facesContext.getExternalContext().getRequest(),
                (HttpServletResponse) facesContext.getExternalContext().getResponse(),
                AuthenticationParameters.withParams().credential(credential)
        );

        switch (status) {
            case SEND_CONTINUE:
                LOG.info("login continue");
                break;
            case SEND_FAILURE:
                LOG.info("login failure");
                return "/error.xhtml";
            case SUCCESS:
                LOG.info("login success");
                break;
            case NOT_DONE:
                LOG.info("login not done");
                return "/error.xhtml";
        }

        return "/welcome.xhtml?faces-redirect=true";
    }

    /**
     *
     * @return
     */
    public String doLogout() {
          LOG.info("Inside  loginController ->  doLogout()  ");

        try {
            HttpServletRequest req = (HttpServletRequest) facesContext.getExternalContext().getRequest();
            req.logout();

        } catch (ServletException ex) {
            LOG.log(Level.SEVERE, null, ex);
            return "/error.xhtml";
        }

        LOG.info("Logged out and redirecting to login page");
        return "/login.xhtml?faces-redirect=true";

    }

    /**
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     */
    public boolean isAdmin() {
        return securityContext.isCallerInRole("ADMIN_ROLE");
    }

    /**
     *
     * @return
     */
    public boolean isEmployee() {
        return securityContext.isCallerInRole("EMP_ROLE");
    }

    /**
     *
     * @return
     */
    public boolean isManager() {
        return securityContext.isCallerInRole("MGR_ROLE");
    }

    /**
     *
     * @return
     */
    public String getRoles() {
        return securityContext.toString();
    }

    /**
     *
     * @return
     */
    public String getNewPassword() {
        return newPassword;
    }

    /**
     *
     * @param newPassword
     */
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    /**
     *
     * @param u
     * @param p
     * @return
     */
    public String updatePassword(String u, String p) {
        LOG.info("Inside update password" + u + " password = " + p + "  newpass =" + this.newPassword);
        userSvc.updatePassword(u, this.newPassword);

        return "/profile.xhtml?faces-redirect=true";
    }
}
