/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketPriority;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatus;
import edu.iit.sat.itmd4515.dbapat.domain.TicketType;
import edu.iit.sat.itmd4515.dbapat.service.EmployeeService;
import edu.iit.sat.itmd4515.dbapat.service.TeamService;
import edu.iit.sat.itmd4515.dbapat.service.TicketService;
import edu.iit.sat.itmd4515.dbapat.service.TicketStatusUpdateService;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * Employee Controller is the Middle layer that connects to both the view and
 * the database (through services)
 *
 * All the CRUD operations for employee are triggered from this controller
 *
 * @author bapat
 */
@Named
@RequestScoped
public class EmployeeController {

    private static final Logger LOG = Logger.getLogger(EmployeeController.class.getName());

    @EJB
    private EmployeeService empSvc;

    @EJB
    private TeamService teamSvc;

    private Employee employee;

    private Team team;
    @EJB
    private TicketService tckSvc;

    @EJB
    private TicketStatusUpdateService tckstupSvc;

    private Ticket ticket;
    @Inject
    LoginController loginController;

    private List<Team> teams;
    private List<Ticket> tickets;
    private Ticket updateTicket;

    @PostConstruct
    private void postConstruct() {

        employee = empSvc.findByUsername(loginController.getRemoteUser());
        if (!employee.getTeams().isEmpty()) {
            tickets = tckSvc.findByTeam(employee.getTeams());
        }
        team = new Team();
        ticket = new Ticket();
        updateTicket = new Ticket();
        teams = employee.getTeams();

    }

    /**
     *
     * @return
     */
    public List<Team> getTeams() {
        return teams;
    }

    /**
     *
     * @param teams
     */
    public void setTeams(List<Team> teams) {
        this.teams = teams;
    }

    /**
     *
     * @return
     */
    public Team getTeam() {
        return team;
    }

    /**
     *
     * @param team
     */
    public void setTeam(Team team) {
        this.team = team;
    }

    /**
     *
     * @return
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     *
     * @param employee
     */
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    /**
     *
     * @return
     */
    public Ticket getTicket() {
        return ticket;
    }

    /**
     *
     * @param ticket
     */
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     *
     * @return
     */
    public TicketType[] getTicketTypes() {
        return TicketType.values();
    }

    /**
     *
     * @return
     */
    public TicketPriority[] getTicketPrioritys() {
        return TicketPriority.values();
    }

    /**
     *
     * @return
     */
    public TicketStatus[] getTicketStatuses() {
        return TicketStatus.values();
    }

    /**
     * preparing view team
     *
     * @param t
     * @return
     */
    public String prepareViewTeam(Team t) {
        LOG.info("Emp prepareViewTeam   " + t.toString());
        this.team = t;
        return "/emp/viewTeam.xhtml";
    }

    /**
     * preparing view employee
     *
     * @param e
     * @return
     */
    public String prepareViewEmployee(Employee e) {
        LOG.info("Emp prepareViewTeam   " + e.toString());
        this.employee = e;
        return "/emp/viewProfile.xhtml";
    }

    /**
     * preparing edit employee
     *
     * @param e
     * @return
     */
    public String prepareEditEmployee(Employee e) {
        LOG.info("Emp prepareEditTeam   " + e.getFirstName());
        this.employee = e;
        return "/emp/editProfile.xhtml";
    }

    /**
     * prepare create employee
     *
     * @return
     */
    public String prepareCreateEmployee() {
        LOG.info("emp prepareCreateTeam");
        this.team = new Team();
        return "/emp/editProfile.xhtml";
    }

    /**
     * save new employee, update if existing
     *
     * @return
     */
    public String doSaveEmployee() {

        if (this.employee.getId() != null) {
            LOG.info("doSave Preparing to call an update in the service layer with " + this.employee.toString());
            empSvc.update(employee);
        }

        return "/emp/myProfile.xhtml?faces-redirect=true";
    }

    /**
     * preapre view ticket
     *
     * @param t
     * @return
     */
    public String prepareViewTicket(Ticket t) {
        LOG.info("Inside Emp viewTicket" + t.getTicketTitle());
        this.ticket = t;
        return "/emp/viewTicket.xhtml";
    }

    /**
     * preapre update ticket created
     *
     * @param t
     * @return
     */
    public String prepareUpdateTicketCreated(Ticket t) {
        LOG.info("Inside Emp prepare Update Ticket created" + t.getTicketTitle());
        this.ticket = t;
        return "/emp/updateTicketCreated.xhtml";
    }

    /**
     * prepare update ticket received
     *
     * @param t
     * @return
     */
    public String prepareUpdateTicketReceived(Ticket t) {
        LOG.info("Inside Emp prepare Update Ticket created" + t.getTicketTitle());
        this.ticket = t;
        return "/emp/updateTicketReceived.xhtml";
    }

    /**
     * prepare create ticket
     *
     * @return
     */
    public String prepareCreateTicket() {
        LOG.info("Inside Emp prepareCreateTicket");
        this.ticket = new Ticket();
        return "/emp/createTicket.xhtml";
    }

    /**
     * create ticket if does not exist already.
     *
     * @return
     */
    public String createTicket() {
        LOG.info("Inside createTicket()");
        tckSvc.createAndAddTicketByEmployee(ticket, employee);
        return "/emp/ticketsManageCreated.xhtml?faces-redirect=true";
    }

    /**
     * update ticket that is already created
     *
     * @return
     */
    public String doUpdateTicketCreated() {

        if (this.ticket.getId() != null) {
            LOG.info("Inside  EmployeeController ->  update ticket created()  ");
            tckSvc.updateCreatedTicket(ticket, employee);
        }
        return "/emp/ticketsManageCreated.xhtml?faces-redirect=true";

    }

    /**
     * update ticket received.
     *
     * @return
     */
    public String doUpdateTicketReceived() {

        if (this.ticket.getId() != null) {
            LOG.info("Inside  EmployeeController ->  update ticket received()  ");
            tckSvc.updateReceivedTicket(ticket, employee);
        }

        return "/emp/ticketsManageReceived.xhtml?faces-redirect=true";

    }

}
