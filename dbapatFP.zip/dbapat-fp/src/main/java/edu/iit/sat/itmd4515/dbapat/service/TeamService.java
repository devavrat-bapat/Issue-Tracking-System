/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatusUpdate;
import edu.iit.sat.itmd4515.dbapat.domain.security.Group;
import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Named;

/**
 * Team service is a class that implements all the service layer methods of
 * Abstract Service.
 *
 * This class has methods to create, update and delete Teams. These methods will
 * primarily work with Team entity. But they will also touch other entities like
 * Employee and Ticket.
 *
 *
 * This will ensure smooth addition/deletion of records and will also maintain
 * the PK-FK relationships.
 *
 *
 * @author bapat
 */
@Named
@Stateless
public class TeamService extends AbstractService<Team> {

    private static final Logger LOG = Logger.getLogger(TeamService.class.getName());

    @EJB
    GroupService grpSvc;
    @EJB
    UserService usrSvc;

    @EJB
    EmployeeService empSvc;

    /**
     *
     */
    public TeamService() {
        super(Team.class);
    }

    /**
     * Find all teams
     *
     * @return
     */
    @Override
    public List<Team> findAll() {
        return em.createNamedQuery("Team.findAll", entityClass).getResultList();
    }

    /**
     * find all teams when the provided username is an employee inside the team
     *
     * @param username
     * @return
     */
    public List<Team> findByMember(String username) {
        return (List<Team>) em.createNamedQuery("Team.findByMember", Team.class).setParameter("username", username).getSingleResult();

    }

    /**
     * find only one team by id
     *
     * @param id
     * @return
     */
    public Team findById(Long id) {
        LOG.info("Inside findByID() " + id);
        return (Team) em.createNamedQuery("Team.findById", Team.class).setParameter("id", id).getSingleResult();

    }

    /**
     * find multiple teams by list of Ids
     *
     * @param id
     * @return
     */
    public List<Team> findTeamById(Long id) {
        LOG.info("Inside findByID() " + id);
        return em.createNamedQuery("Team.findById", Team.class).setParameter("id", id).getResultList();

    }

    /**
     * Find team by their team members
     *
     * @param team
     * @return
     */
    public Team findByTeamMember(List<Team> team) {
        return (Team) em.createNamedQuery("Team.findByTeamMember", Team.class).setParameter("team", team).getResultList();

    }

    /**
     *
     * Find team by its manager id
     *
     * @param manager
     * @return
     */
    public List<Team> findByTeamManager(Employee manager) {
        return em.createNamedQuery("Team.findByTeamManager", Team.class).setParameter("manager", manager).getResultList();

    }

    /**
     * Find teams by member ids.
     *
     * @param employee
     * @return
     */
    public List<Team> findTeamsByMember(Employee employee) {
        return em.createNamedQuery("Team.findTeamsByMember", Team.class).setParameter("employee", employee).getResultList();

    }

    /**
     * Create a new Team and assign a manager to it. We also add the employees
     * selected to the team.
     *
     * @param team
     * @param manager
     */
    public void createAndAddTeamByManager(Team team, Employee manager) {

        manager = em.getReference(Employee.class, manager.getId());

        super.create(team);
        em.flush();

        team.setManager(manager);
        team.setManagerId(manager.getId());
        manager.addTeam(team);

        em.merge(manager);

        List<Employee> employee = new ArrayList<>(team.getEmp());

        Team teamInDatabase = em.getReference(Team.class, team.getId());
        employee.forEach((Employee e) -> {

            e.addTeam(teamInDatabase);
            em.merge(e);
        });
    }

    /**
     *
     * Update team information. Input is provided by the manager of that team.
     *
     * @param teamFromManagerForm
     */
    public void editTeamByManager(Team teamFromManagerForm) {

        Team teamFromDatabase = em.getReference(Team.class, teamFromManagerForm.getId());
        teamFromDatabase.setName(teamFromManagerForm.getName());
        em.merge(teamFromDatabase);

    }

    /**
     * Create a team by admin. Add employees, and set a manager to the team.
     *
     * @param teamFromAdminForm
     */
    public void createAndAddTeamByAdmin(Team teamFromAdminForm) {

        List<Employee> employee = new ArrayList<>(teamFromAdminForm.getEmp());
        teamFromAdminForm.setEmp(null);
        em.persist(teamFromAdminForm);
        em.flush();
        Team teamInDatabase = em.getReference(Team.class, teamFromAdminForm.getId());
        employee.forEach((Employee e) -> {
            e.addTeam(teamInDatabase);
            em.merge(e);
        });
        Employee manager = em.getReference(Employee.class, teamFromAdminForm.getManagerId());
        Group mgrGroup = grpSvc.findManagerGroup();
        User emp2 = usrSvc.findByUsername(manager.getUser().getUserName());
        emp2.setPassword("newManager123");
        List<Group> g1 = new ArrayList<>(emp2.getGroups());
        if (!g1.contains(mgrGroup)) {
            emp2.addGroup(mgrGroup);
        }
        grpSvc.update(mgrGroup);
        usrSvc.update(emp2);
        if (!manager.getTeams().contains(teamInDatabase)) {
            manager.addTeam(teamInDatabase);
        }
        empSvc.update(manager);

    }

    /**
     *
     * Update team. Handle the list of employees changed. - If user adds new
     * members to the team, then add employees to the team in database . If user
     * removes some employees from the team in database, then remove them.
     * Handle the change of manager. If an employee with only EMP_GROUP assigned
     * is created a Manager , then assign the MGR_GROUP to the employee.
     *
     *
     * @param teamFromUserForm
     */
    @Override
    public void update(Team teamFromUserForm) {

        Team teamInDatabase = em.getReference(Team.class, teamFromUserForm.getId());
        if (teamFromUserForm.getName() != null) {
            teamInDatabase.setName(teamFromUserForm.getName());
        }
        if (teamFromUserForm.getManager() != null) {
            teamInDatabase.setManager(teamFromUserForm.getManager());
        }

        List<Employee> employeesFromForm = new ArrayList<>(teamFromUserForm.getEmp());

        employeesFromForm.forEach((Employee e) -> {
            if (!teamInDatabase.getEmp().contains(e)) {
                e.addTeam(teamInDatabase);
            }
            em.merge(e);
        });

        List<Employee> employeesInDatabase = new ArrayList<>(teamInDatabase.getEmp());
        employeesInDatabase.forEach((Employee e) -> {
            if (!teamFromUserForm.getEmp().contains(e)) {
                e.removeTeam(teamInDatabase);
            }
            em.merge(e);
        });

        if (teamInDatabase.getManager() != null) {
            Employee manager = em.getReference(Employee.class, teamInDatabase.getManager().getId());

            if (!manager.getTeams().contains(teamInDatabase)) {
                manager.addTeam(teamInDatabase);
            }
            Group mgrGroup = grpSvc.findManagerGroup();
            User emp2 = usrSvc.findByUsername(manager.getUser().getUserName());
            List<Group> g1 = new ArrayList<>(emp2.getGroups());

            if (!g1.contains(mgrGroup)) {
                emp2.addGroup(mgrGroup);
                emp2.setPassword("newManager123");
                grpSvc.update(mgrGroup);
                usrSvc.update(emp2);
            }

            if (!manager.getTeams().contains(teamInDatabase)) {
                manager.addTeam(teamInDatabase);
            }
            em.merge(manager);
        }
        em.merge(teamInDatabase);
    }

    /**
     * Delete team from Manager. Remove all the ticket updates of tickets that
     * were created by this team and that were dispatched to this team.
     *
     * Removing ticket updates to comply with the PK-FK constraint for One to
     * many relationship.
     *
     *
     * Then remove the tickets that were created by and dispatched to this team.
     *
     * Then remove the employees from the team
     *
     * Then remove the manager set to this team
     *
     * Then delete this team.
     *
     * @param teamFromUserForm
     */
    @Override
    public void remove(Team teamFromUserForm) {

        Team teamFromDatabase = em.getReference(Team.class,
                teamFromUserForm.getId());

        List<Ticket> ticketsCreatedToRemove = new ArrayList<>(teamFromDatabase.getTickets());

        ticketsCreatedToRemove.forEach((Ticket t) -> {
            List<TicketStatusUpdate> ticketUpdatesToRemove = new ArrayList<>(t.getTckstup());

            ticketUpdatesToRemove.forEach((TicketStatusUpdate tu) -> {
                tu.getTicket().removeTicketStatusUpdate(tu);
                em.remove(tu);
            });

            t.getTeam().removeTicketsCreated(t);
            t.getEmp().removeTickets(t);
            t.getTicketDispatchTo().removeTicketsDispatched(t);
            em.remove(t);
        });

        List<Ticket> ticketsDispatchedToRemove = new ArrayList<>(teamFromDatabase.getTicketsDispatched());

        ticketsDispatchedToRemove.forEach((Ticket t) -> {
            List<TicketStatusUpdate> ticketUpdatesToRemove = new ArrayList<>(t.getTckstup());

            ticketUpdatesToRemove.forEach((TicketStatusUpdate tu) -> {
                tu.getTicket().removeTicketStatusUpdate(tu);
                em.remove(tu);
            });
            t.getTeam().removeTicketsCreated(t);
            t.getEmp().removeTickets(t);
            t.getTicketDispatchTo().removeTicketsDispatched(t);
            em.remove(t);
        });
        List<Employee> employee = new ArrayList<>(teamFromDatabase.getEmp());
        employee.forEach((Employee e) -> {
            e.removeTeam(teamFromDatabase);
            em.merge(e);
        });
        em.remove(teamFromDatabase);
    }
}
