/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

/**
 * A ticket can have 4 types of status -
 *
 *
 * Open - A new created ticket which hasn't been worked on at all. Once a
 * team/employee works on it and applies a temporary fix, they can change the
 * status of the ticket to Restored.
 *
 *
 * Restored - A ticket which has been temporarily suspended or the problem is
 * temporarily fixed. The employee is probably waiting from some action from
 * some other team. But, it also means the team is working on finding a
 * permanent fix.
 *
 *
 * Resolved - A permanent fix has been found and applied to solve the issue.
 * This also means that the employee was monitoring for any other occurrences of
 * the same issue. If the issue persists, then the status has to be changed to
 * Restored and work on the problem.
 *
 * Closed - A permanent fix works! Hurrah.. the problem is totally resolved.
 * There are no more occurrences of the same issue. ALl users are happy that
 * service is fixed. Employees are happy that the problem is fixed. Ticket can
 * be closed now.
 *
 *
 *
 * @author bapat
 */
public enum TicketStatus {

    /**
     * * Open - A new created ticket which hasn't been worked on at all. Once a
     * team/employee works on it and applies a temporary fix, they can change
     * the status of the ticket to Restored.
     */
    OPEN("Open"),
    /**
     * Closed - A permanent fix works! Hurrah.. the problem is totally resolved.
     * There are no more occurrences of the same issue. ALl users are happy that
     * service is fixed. Employees are happy that the problem is fixed. Ticket
     * can be closed now.
     */
    CLOSED("Closed"),
    /**
     * Restored - A ticket which has been temporarily suspended or the problem
     * is temporarily fixed. The employee is probably waiting from some action
     * from some other team. But, it also means the team is working on finding a
     * permanent fix.
     *
     */
    RESTORED("Restored"),
    /**
     *
     * Resolved - A permanent fix has been found and applied to solve the issue.
     * This also means that the employee was monitoring for any other
     * occurrences of the same issue. If the issue persists, then the status has
     * to be changed to Restored and work on the problem.
     */
    RESOLVED("Resolved");

    private String label;

    private TicketStatus(String label) {
        this.label = label;
    }

    /**
     *get the label name
     * @return
     */
    public String getLabel() {
        return label;
    }
}
