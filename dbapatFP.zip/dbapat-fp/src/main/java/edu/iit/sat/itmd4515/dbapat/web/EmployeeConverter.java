/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.service.EmployeeService;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

/**
 *
 * This class implements Converter.
 *
 * We use this class to convert Employee type object to String and vice versa.
 *
 * @author bapat
 */
@FacesConverter(value = "employeeConverter", managed = true)
public class EmployeeConverter implements Converter {

    private static final Logger LOG = Logger.getLogger(EmployeeConverter.class.getName());

    @Inject
    private EmployeeService empSvc;

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return empSvc.find(Long.valueOf(value));
    }
    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value == null) {
            return "";
        }
        return String.valueOf(((Employee) value).getId());
    }
}
