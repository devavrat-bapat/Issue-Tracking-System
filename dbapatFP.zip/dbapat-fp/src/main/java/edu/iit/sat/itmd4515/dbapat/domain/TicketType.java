/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

/**
 *
 * @author bapat
 */
public enum TicketType {

    /**
     * Ticket can be of type - Incident. An incident is an event when the system
     * is completely shut down or there is a huge outage on the services.
     * Incident is a severe issue and must be taken care of immediately.
     *
     * An example of an incident could be - the database service is not running
     * in the production/Live environment. Then , the responsible team must
     * raise a ticket of type incident and dispatch to the database team.
     *
     * The database team will then start the database services and change the
     * status of the ticket to restored or resolved.
     *
     * Then the ticket is supposed to be sent back to the team who created it to
     * provide Sign-off
     *
     */
    INCIDENT("Incident"),
    /**
     * Ticket can be of type - Service request. A service request could also be
     * an event when the system is not working as expected, but, problem is not
     * very severe as it impacts only a few number of users.
     *
     * Also, a service request can be raised for lower priority environments
     * like Test or Development, etc.
     *
     * A service request means a some team is waiting for some other team to
     * take an action.
     */
    SERVICEREQUEST("Service Request");

    private String label;

    private TicketType(String label) {
        this.label = label;
    }

    /**
     *Retrieve the label of the ticket type
     * @return
     */
    public String getLabel() {
        return label;
    }
}
