/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Version;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

/**
 *
 * The most fundamental concept of the application - a Ticket.
 *
 * A ticket identifies an issue that an employee/team is currently working on. A
 * team might need help from other team/s. Every employee is expected to provide
 * clear , concise information about the tasks he has done for the ticket in a
 * timely manner.
 *
 * Type of the issue decides what type of ticket an employee must raise.
 * Also he has to decide the priority and date when the ticket is supposed to be resolved.
 * 
 *
 * @author bapat
 *
 */
@Entity
@NamedQuery(name = "Ticket.findById", query = "SELECT t from Ticket t where t.id = :id")
@NamedQuery(name = "Ticket.findAll", query = "SELECT t from Ticket t")
@NamedQuery(name = "Ticket.findByTeam", query = "SELECT t from Ticket t WHERE t.team IN :team_id")
@NamedQuery(name = "Ticket.findByTeamDispatched", query = "SELECT t from Ticket t WHERE t.ticketDispatchTo IN :team_id")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Version
    private Long version;
    private static final Logger LOG = Logger.getLogger(Ticket.class.getName());

    @Enumerated(EnumType.STRING)
    private TicketType ticketType;

    @JoinColumn(name = "ticketDispatchTo", nullable = false)
    @ManyToOne
    @NotNull
    private Team ticketDispatchTo;

    @NotNull
    @PastOrPresent
    private LocalDate ticketCreatedOn;

    @NotNull
    @FutureOrPresent
    @Column(nullable = false)
    private LocalDate ticketResolveByDate;

    @NotBlank
    @NotNull
    private String ticketMessage;

    @NotBlank
    @NotNull
    private String ticketTitle;

    @Enumerated(EnumType.STRING)
    @NotNull
    private TicketPriority ticketPriority;

    @Enumerated(EnumType.STRING)
    @NotNull
    private TicketStatus ticketStatus;

    @ManyToOne
    private Employee emp;

    @NotNull
    @ManyToOne
    private Team team;

    @OneToMany(mappedBy = "ticket")
    private List<TicketStatusUpdate> tckstup = new ArrayList<>();

    private LocalDateTime lastUpdatedTime;
    private LocalDateTime createdTime;

    /**
     *
     * get Team which raised the ticket
     * @return
     */
    public Team getTeam() {
        return team;
    }

    /**
     *set Team which raised the ticket
     * @param team
     */
    public void setTeam(Team team) {
        this.team = team;
    }

    /**
     * get incremented version of the ticket every time it is updated
     * @return
     */
    public Long getVersion() {
        return version;
    }

    /**
     *set incremented version of the ticket every time it is updated
     * @param version
     */
    public void setVersion(Long version) {
        this.version = version;
    }

    /**
     *
     * @return
     */
    public Team getTicketDispatchTo() {
        return ticketDispatchTo;
    }

    /**
     *
     * @param ticketDispatchTo
     */
    public void setTicketDispatchTo(Team ticketDispatchTo) {
        this.ticketDispatchTo = ticketDispatchTo;
    }

    /**
     *
     * @return
     */
    public Employee getEmp() {
        return emp;
    }

    /**
     *
     * @param emp
     */
    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    /**
     *
     * @return
     */
    public TicketStatus getTicketStatus() {
        return ticketStatus;
    }

    /**
     *
     * @param ticketStatus
     */
    public void setTicketStatus(TicketStatus ticketStatus) {
        this.ticketStatus = ticketStatus;
    }

    /**
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getTicketTitle() {
        return ticketTitle;
    }

    /**
     *
     * @param ticketTitle
     */
    public void setTicketTitle(String ticketTitle) {
        this.ticketTitle = ticketTitle;
    }

    /**
     *
     */
    public Ticket() {
    }

    /**
     *
     * @return
     */
    public List<TicketStatusUpdate> getTckstup() {
        return tckstup;
    }

    /**
     *
     * @param tckstup
     */
    public void setTckstup(List<TicketStatusUpdate> tckstup) {
        this.tckstup = tckstup;
    }

    /**
     *
     * @return
     */
    public LocalDate getTicketResolveByDate() {
        return ticketResolveByDate;
    }

    /**
     *
     * @param ticketResolveByDate
     */
    public void setTicketResolveByDate(LocalDate ticketResolveByDate) {
        this.ticketResolveByDate = ticketResolveByDate;
    }

    /**
     *
     * @return
     */
    public String getTicketMessage() {
        return ticketMessage;
    }

    /**
     *
     * @param ticketMessage
     */
    public void setTicketMessage(String ticketMessage) {
        this.ticketMessage = ticketMessage;
    }

    /**
     *
     * @return
     */
    public LocalDate getTicketCreatedOn() {
        return ticketCreatedOn;
    }

    /**
     *
     * @param ticketCreatedOn
     */
    public void setTicketCreatedOn(LocalDate ticketCreatedOn) {
        this.ticketCreatedOn = ticketCreatedOn;
    }

    /**
     *
     * @return
     */
    public TicketType getTicketType() {
        return ticketType;
    }

    /**
     *
     * @param ticketType
     */
    public void setTicketType(TicketType ticketType) {
        this.ticketType = ticketType;
    }

    /**
     *
     * @return
     */
    public TicketPriority getTicketPriority() {
        return ticketPriority;
    }

    /**
     *
     * @param ticketPriority
     */
    public void setTicketPriority(TicketPriority ticketPriority) {
        this.ticketPriority = ticketPriority;
    }

    /**
     *
     * @return
     */
    public LocalDateTime getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    /**
     *
     * @param lastUpdatedTime
     */
    public void setLastUpdatedTime(LocalDateTime lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    /**
     *
     * @return
     */
    public LocalDateTime getCreatedTime() {
        return createdTime;
    }

    /**
     *
     * @param createdTime
     */
    public void setCreatedTime(LocalDateTime createdTime) {
        this.createdTime = createdTime;
    }

    /**
     *
     * @param tckstup
     */
    public void addTicketStatusUpdate(TicketStatusUpdate tckstup) {
        if (!this.tckstup.contains(tckstup)) {
            this.tckstup.add(tckstup);
        }
    }

    @PrePersist
    private void prePersists() {
        createdTime = LocalDateTime.now();
        lastUpdatedTime = LocalDateTime.now();

    }

    /**
     *
     * @param t
     */
    public void removeTicketStatusUpdate(TicketStatusUpdate t) {
        if (this.tckstup.contains(t)) {
            this.tckstup.remove(t);
        }
        LOG.info("remove Ticketstatusupdated exited");

    }

    @PreUpdate
    private void preUpdate() {
        lastUpdatedTime = LocalDateTime.now();

    }

    @Override
    public String toString() {
        return "Ticket{" + "id=" + id + "ticket created by team" + team.getName() + " ticket created by employee" + emp.getFirstName() + "id=" + id + "" + ", ticketType=" + ticketType
                + ", ticketDispatchTo=" + ticketDispatchTo + ", ticketCreatedOn=" + ticketCreatedOn
                + ", ticketResolveByDate=" + ticketResolveByDate + ", ticketMessage=" + ticketMessage
                + ", ticketTitle=" + ticketTitle + ", ticketPriority=" + ticketPriority + ", ticketStatus=" + ticketStatus + '}';
    }

    /**
     * Parameterized Constructor
     * @param ticketType
     * @param ticketDispatchTo
     * @param ticketCreatedOn
     * @param ticketResolveByDate
     * @param ticketMessage
     * @param ticketTitle
     * @param ticketPriority
     * @param ticketStatus
     * @param emp
     * @param team
     */
    public Ticket(TicketType ticketType, Team ticketDispatchTo, LocalDate ticketCreatedOn,
            LocalDate ticketResolveByDate, String ticketMessage, String ticketTitle, TicketPriority ticketPriority, TicketStatus ticketStatus,
            Employee emp, Team team) {
        this.ticketType = ticketType;
        this.ticketDispatchTo = ticketDispatchTo;
        this.ticketCreatedOn = ticketCreatedOn;
        this.ticketResolveByDate = ticketResolveByDate;
        this.ticketMessage = ticketMessage;
        this.ticketTitle = ticketTitle;
        this.ticketPriority = ticketPriority;
        this.ticketStatus = ticketStatus;
        this.emp = emp;
        this.team = team;
    }
}
