package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import java.util.List;
import java.util.logging.Logger;
import javax.ejb.Stateless;

/**
 * Referenced from Instructor example
 *
 * User service class is used to implement create, update and remove methods
 * over the database.
 *
 * This class also facilitates us with methods that run queries for User class
 * and retrieve Users with custom conditions.
 *
 * @author bapat
 */
@Stateless
public class UserService extends AbstractService<User> {

    private static final Logger LOG = Logger.getLogger(UserService.class.getName());

    /**
     * default
     */
    public UserService() {
        super(User.class);
    }

    /**
     * Find all the users
     *
     * @return
     */
    @Override
    public List<User> findAll() {
        return em.createNamedQuery("User.findAll", entityClass).getResultList();
    }

    /**
     * Find user by providing username
     *
     * @param username
     * @return
     */
    public User findByUsername(String username) {
        return em.createNamedQuery("User.findByUsername", entityClass).setParameter("userName", username).getSingleResult();
    }

    /**
     * Update the password provided by the user
     *
     * @param username
     * @param password
     */
    public void updatePassword(String username, String password) {
        User user = em.getReference(User.class, username);
        user.setPassword(password);
    }

}
