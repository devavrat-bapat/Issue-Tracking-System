/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.service.TeamService;
import java.util.logging.Logger;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;

/**
 *
 * TeamConverter class implements the Converter interface.
 *
 *This class is used to convert objects of type Team to String and vice versa.
 *
 * @author bapat
 */
@FacesConverter(value = "teamConverter", managed = true)
public class TeamConverter implements Converter {

    private static final Logger LOG = Logger.getLogger(TeamConverter.class.getName());

    @Inject
    private TeamService teamSvc;

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isEmpty()) {
            return null;
        }
        return teamSvc.find(Long.valueOf(value));
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value == null) {
            return "";
        }
        return String.valueOf(((Team) value).getId());
    }

}
