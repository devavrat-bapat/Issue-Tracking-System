/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
Lab 7
 */
package edu.iit.sat.itmd4515.dbapat.service;

import edu.iit.sat.itmd4515.dbapat.domain.Employee;
import edu.iit.sat.itmd4515.dbapat.domain.Team;
import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.domain.TicketPriority;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatus;
import edu.iit.sat.itmd4515.dbapat.domain.TicketStatusUpdate;
import edu.iit.sat.itmd4515.dbapat.domain.TicketType;
import edu.iit.sat.itmd4515.dbapat.domain.security.Group;
import edu.iit.sat.itmd4515.dbapat.domain.security.User;
import java.time.LocalDate;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * Referenced from Instructor example Startup
 *
 * This class is used to populate the database with same data.
 *
 * @author bapat
 */
@Startup
@Singleton
public class StartupSeedDatabase {

    @EJB
    private TicketService tckSrv;
    @EJB
    private EmployeeService empSrv;
    @EJB
    private TeamService teamSrv;
    private static final Logger LOG = Logger.getLogger(StartupSeedDatabase.class.getName());
    @EJB
    private UserService userSvc;
    @EJB
    private GroupService groupSvc;

    @EJB
    private TicketStatusUpdateService tckstupSvc;

    /**
     *
     */
    public StartupSeedDatabase() {
    }

    @PostConstruct
    private void seedDatabase() {

        User adminUser = new User("admin", "admin", true);
        Group adminGroup = new Group("ADMIN_GROUP", "This is admin group.");

        adminUser.addGroup(adminGroup);
        groupSvc.create(adminGroup);
        userSvc.create(adminUser);

        Group mgrGroup = new Group("MGR_GROUP", "Identity Store group of managers");
        Group empGroup = new Group("EMP_GROUP", "Identity Store group of employees");

        User emp1 = new User("emp1", "emp1", true);
        User mgr1 = new User("mgr1", "mgr1", true);
        User emp2 = new User("emp2", "emp2", true);
        User emp3 = new User("emp3", "emp3", true);
        User emp4 = new User("emp4", "emp4", true);
        User dev1 = new User("dev1", "dev1", true);

        emp1.addGroup(empGroup);
        emp2.addGroup(empGroup);
        emp3.addGroup(empGroup);
        dev1.addGroup(empGroup);
        mgr1.addGroup(empGroup);
        emp4.addGroup(empGroup);

        mgr1.addGroup(mgrGroup);
        dev1.addGroup(mgrGroup);

        groupSvc.create(empGroup);
        groupSvc.create(mgrGroup);
        userSvc.create(mgr1);
        userSvc.create(dev1);
        userSvc.create(emp1);
        userSvc.create(emp2);
        userSvc.create(emp3);
        userSvc.create(emp4);

        Employee m1 = new Employee("Tony", "Stark", "asd@hawk.iit.edu", "6846", "Marvels", LocalDate.of(1993, 01, 01));
        m1.setUser(mgr1);

        Employee d1 = new Employee("Devavrat", "Bapat", "dbapat@hawk.iit.edu", "1234", "chicago", LocalDate.of(1994, 03, 14));
        d1.setUser(dev1);

        Employee e1 = new Employee("Jon", "Snow", "wer@hawk.iit.edu", "65848", "Winterfell", LocalDate.of(1992, 01, 01), d1);
        e1.setUser(emp1);

        Employee e2 = new Employee("Mike", "Simon", "mike@gmail.com", "34234", "new york", LocalDate.of(1991, 11, 11), m1);
        e2.setUser(emp2);

        Employee e3 = new Employee("Derek", "Smith", "derek@gmail.com", "987634", "san diego", LocalDate.of(1997, 07, 07), m1);
        e3.setUser(emp3);

        Employee e4 = new Employee("Sunil", "Jacob", "jacob@gmail.com", "3643", "dallas", LocalDate.of(1992, 05, 12), m1);
        e4.setUser(emp4);

        Team team = new Team("IT HelpDesk", m1);
        Team team1 = new Team("HR Team", m1);
        Team team2 = new Team("Mainframes", m1);
        Team team3 = new Team("ORASQLDBA", d1);
        Team team4 = new Team("FrontEndDevelopers", d1);
        Team team5 = new Team("BackEndDevelopers", d1);
        Team team6 = new Team("DataScientists", d1);

        m1.addTeam(team);
        m1.addTeam(team1);
        m1.addTeam(team2);

        e2.addTeam(team);
        e3.addTeam(team1);
        e4.addTeam(team2);

        d1.addTeam(team3);
        d1.addTeam(team4);
        d1.addTeam(team5);
        d1.addTeam(team6);

        e1.addTeam(team3);
        e1.addTeam(team4);
        e1.addTeam(team5);
        e1.addTeam(team6);

        Ticket t1 = new Ticket(TicketType.INCIDENT, team3, LocalDate.of(2019, 03, 19), LocalDate.of(2019, 06, 15), "404 error: Page not found", "Database services not running", TicketPriority.P1, TicketStatus.OPEN, e1, team4);
        Ticket t2 = new Ticket(TicketType.SERVICEREQUEST, team4, LocalDate.of(2019, 04, 05), LocalDate.of(2019, 05, 15), "Null Pointer exception", "Object is not instantiated properly", TicketPriority.P2, TicketStatus.OPEN, d1, team5);
        Ticket t3 = new Ticket(TicketType.INCIDENT, team2, LocalDate.of(2019, 03, 19), LocalDate.of(2019, 07, 05), "Recursive calls to the function are causing stack overflow error. Its the .toString() method ", "stack overflow error", TicketPriority.P3, TicketStatus.OPEN, m1, team);

        TicketStatusUpdate tckstup1 = new TicketStatusUpdate(t1);
        TicketStatusUpdate tckstup2 = new TicketStatusUpdate(t2);
        TicketStatusUpdate tckstup3 = new TicketStatusUpdate(t3);

        e1.addTickets(t1);
        d1.addTickets(t2);
        m1.addTickets(t3);

        team3.addTicketsDispatched(t1);
        team4.addTicketsDispatched(t2);
        team2.addTicketsDispatched(t3);

        team4.addTicketsCreated(t1);
        team5.addTicketsCreated(t2);
        team.addTicketsCreated(t3);

        t1.addTicketStatusUpdate(tckstup1);
        t2.addTicketStatusUpdate(tckstup2);
        t3.addTicketStatusUpdate(tckstup3);

        empSrv.create(m1);
        empSrv.create(e1);
        empSrv.create(e2);
        empSrv.create(e3);
        empSrv.create(e4);
        empSrv.create(d1);

        teamSrv.create(team);
        teamSrv.create(team1);
        teamSrv.create(team2);
        teamSrv.create(team3);
        teamSrv.create(team4);
        teamSrv.create(team5);
        teamSrv.create(team6);

        tckSrv.create(t1);
        tckSrv.create(t2);
        tckSrv.create(t3);

        tckstupSvc.create(tckstup1);
        tckstupSvc.create(tckstup2);
        tckstupSvc.create(tckstup3);
    }
}
