/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.web;

import edu.iit.sat.itmd4515.dbapat.domain.Ticket;
import edu.iit.sat.itmd4515.dbapat.service.TicketService;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 * Ticket controller class acts as a middle man between the view and database
 * operations (services)
 *
 *
 * @author bapat
 */
@Named
@RequestScoped
public class TicketController {

    private static final Logger LOG = Logger.getLogger(TicketController.class.getName());

    @EJB
    private TicketService tckSvc;

    private Ticket ticket;

    /**
     * default
     */
    public TicketController() {
    }

    /**
     *
     * @return
     */
    public Ticket getTicket() {
        return ticket;
    }

    /**
     *
     * @param ticket
     */
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    /**
     *
     */
    @PostConstruct
    public void postConstruct() {
        LOG.info("Inside ticket controller.postConstruct()");
        ticket = new Ticket();
    }

    /**
     *
     *
     * Save ticket
     *
     * @return
     */
    public String executeSaveTicket() {
        LOG.info("Inside Ticket controller.executeSaveTicket()" + ticket.toString());
        tckSvc.create(ticket);
        return "/admin/ticketOk.xhtml";
    }
}