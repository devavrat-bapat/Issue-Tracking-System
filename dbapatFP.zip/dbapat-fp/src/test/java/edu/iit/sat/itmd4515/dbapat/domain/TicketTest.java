/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import java.time.LocalDate;
import java.util.logging.Logger;
import javax.persistence.RollbackException;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author bapat
 */
public class TicketTest extends AbstractJPATest {

    private static final Logger LOG = Logger.getLogger(TicketTest.class.getName());

    // Below tests whether we can insert/create a new record into database using JPA

 /*      @Test
    public void testCreateNewValidTicket() throws Exception {

        //     Ticket t = new Ticket("A2", "FrontEndDev", "Incident", "BackEndDev", LocalDate.of(2019, 02, 10), "404: Page not found. Dattabase not setup", LocalDate.of(2019, 02, 20), "P3");
        Ticket t = new Ticket(1L, "Service Request", 2L, LocalDate.of(2019, 03, 24), LocalDate.of(2019, 04, 20), "404: Page not found. Database not setup", "Third 404 error", "P2", "Open");
        tx.begin();

        assertNull("testCreateNewValidTicket:     This is null/n", t.getId());                                  // ID should be null before inserting into database
        em.persist(t);
        assertNull("This is null/n", t.getId());                                  // Not inserted yet!!!
        LOG.info("testCreateNewValidTicket       TicketID =" + t.toString());
        tx.commit();
        assertNotNull("This is not null/n", t.getId());                           // post commit() we are sure the record has been inserted.
        LOG.info("testCreateNewValidTicket       Success. Ticket id should be greater than Zero/n" + t.toString());
        assertTrue("Ticket id should be greater than Zero", t.getId() > 0L);

    }

    // Below tests whether we can find/select a record from database using JPA
    @Test
    public void testFindExistingTicket() throws Exception {

        Ticket sample = em.createNamedQuery("Ticket.findByOwner", Ticket.class).setParameter("ticketCreatedById", 3L).getSingleResult();
        assertTrue("Ticket title should match", "Page not found".equals(sample.getTicketTitle()));    // we have already inserted the record before executing this test!
        LOG.info("testFindExistingTicket   We found the record :/n" + sample.toString());
        System.out.println("testFindExistingTicket      We found the record :/n" + sample.toString());                 // Displaying on LOG and standard output
    }

    @Test(expected = RollbackException.class)
    public void testCreateNewInvalidTicket() throws Exception {

//        Ticket t = new Ticket(null, null, "Incident", "BackEndDev", LocalDate.of(2019, 02, 15), "404: Page not found. Dattabase not setup", LocalDate.of(2019, 02, 20), "P3");
        Ticket t = new Ticket(null, null, 3l, LocalDate.of(2019, 03, 15), LocalDate.of(2019, 04, 20), "404: Page not found. Database not setup", "New 404 error", "P3", "Open");
        tx.begin();

        assertNull(" Passing null values where database expects non-null values/n", t.getId());                       // ID should not be null to insert into database
        em.persist(t);
        assertNull(" This test is expected to fail/produce exceptions/n", t.getId());
        tx.commit();
        assertNotNull(" This is null/n", t.getId());
        LOG.info("testCreateInvalidNewValidTicket      This is null/n" + t.toString());
        assertTrue("testCreateInvalidNewValidTicket     Shall retrieve NULL or throw exception/n", t.getId() > 0L);

    }

    // Below tests whether we can remove/delete a record from database using JPA
    @Test
    public void testRemoveTicket() throws Exception {

        // inserting a record
        //     Ticket t = new Ticket("A3", "FrontEndDev", "Incident", "BackEndDev", LocalDate.of(2019, 02, 12), "404: Page not found. Dattabase not setup", LocalDate.of(2019, 02, 20), "P3");
        Ticket t = new Ticket(1l, "Service Request", 2l, LocalDate.of(2019, 03, 15), LocalDate.of(2019, 03, 31), "404: Page not found. Database not setup", "First ever 404 error", "P3", "Open");
        tx.begin();
        em.persist(t);
        tx.commit();

        // viewing the inserted record
        assertNotNull(t.getId());
        LOG.info("testRemoveTicket      Removing this record: /n" + t.toString());

        // Removing/Delting the database record
        tx.begin();
        em.remove(t);
        tx.commit();

        // confirming the same
        assertEquals(t.getTicketTitle(), "First ever 404 error");

        t = em.find(Ticket.class, t.getId());
        assertNull(t);
        LOG.info("testRemoveTicket    Record deleted, hence cannot be found:");

    }

    // Below tests whether we can update/modify a record into database using JPA
    @Test
    public void testUpdateTicket() throws Exception {

        // Ticket t = new Ticket("FrontEndDev", "Incident", "BackEndDev", LocalDate.of(2019, 02, 15), "404: Page not found. Database not setup", LocalDate.of(2019, 02, 20), "P3");
        Ticket t = new Ticket(1l, "Incident", 2l, LocalDate.of(2019, 03, 19), LocalDate.of(2019, 04, 05), "404: Page not found. Database not setup", "Second 404 error", "P3", "Open");
        // inserting a new record
        tx.begin();
        em.persist(t);
        tx.commit();

        // checking whether it has been inserted
        assertNotNull(t.getId());
        assertEquals(t.getTicketTitle(), "Second 404 error");

        // Check message before updating
        LOG.info("testUpdateTicket      Original Ticket message:" + t.getTicketMessage());

        //updating the values in the pojo
        tx.begin();
        em.persist(t);
        t.setTicketMessage("Database server has blocking sessions");
        assertEquals(t.getTicketMessage(), "Database server has blocking sessions");
        LOG.info("testUpdateTicket      Ticket message has been updated to:" + t.getTicketMessage());
        tx.commit();
    }*/
/*    
    @Test
    public void testAllRelationships() {

        // Create Employees -
        Employee e = new Employee("Devavrat", "Bapat", "dbapat@hawk.iit.edu", "1234", "chicago", LocalDate.of(1994, 03, 14));

        // First employee cannot have a manager
        //   e.setManager(e);
        Employee e1 = new Employee("Mike", "Simon", "mike@gmail.com", "34234", "new york", LocalDate.of(1991, 11, 11), e);
        Employee e2 = new Employee("Derek", "Smith", "derek@gmail.com", "987634", "san diego", LocalDate.of(1997, 07, 07), e1);
        Employee e3 = new Employee("Sunil", "Jacob", "jacob@gmail.com", "3643", "dallas", LocalDate.of(1992, 05, 12), e);

        tx.begin();
        em.persist(e);
        em.persist(e1);
        em.persist(e2);
        em.persist(e3);
        tx.commit();

        Team t1 = new Team("BackEnd", e.getId());
        Team t2 = new Team("FrontEnd", e1.getId());
        e.addTeam(t1);
        System.out.println("1");
        e1.addTeam(t2);
        System.out.println("1");
        e2.addTeam(t1);
        e3.addTeam(t2);

        tx.begin();
        em.persist(t1);
        em.persist(t2);
        em.persist(e);
        em.persist(e1);
        em.persist(e2);
        em.persist(e3);
        tx.commit();
        
        // Now all the required teams, employees are inserted into tables. We must now see the relationships
        
         Employee findEmp = em.find(Employee.class, 1l);
        System.out.println("Employee name is: " + findEmp.getFirstName()+" "+findEmp.getLastName());
        assertEquals(e.getFirstName(), findEmp.getFirstName());
        System.out.println("Employee Teams: " + findEmp.getTeams().toString());
        assertEquals(e.getTeams().get(0).getName(), findEmp.getTeams().get(0).getName());
    

        Team findTeam = em.createNamedQuery("Team.findByName", Team.class).setParameter("name", "BackEnd").getSingleResult();
        System.out.println("Team created - " + findTeam.getName());
        assertEquals(t1.getName(), findTeam.getName());
        System.out.println("Team Members - " + findTeam.getEmp().toString());
        assertEquals(t1.getEmp().get(0).getFirstName(), findTeam.getEmp().get(0).getFirstName());

       
    }
*/
}
