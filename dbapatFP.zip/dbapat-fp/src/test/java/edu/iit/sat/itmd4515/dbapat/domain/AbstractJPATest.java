/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.dbapat.domain;

import java.time.LocalDate;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 *
 * @author bapat
 */
public class AbstractJPATest {

    private static EntityManagerFactory emf;
    protected EntityManager em;
    protected EntityTransaction tx;

    @BeforeClass
    public static void beforeClassTestFixturePerClass() {

        emf = Persistence.createEntityManagerFactory("itmd4515testPU");
    }

    @Before
    public void beforeEachTestFixture() {

        em = emf.createEntityManager();
        tx = em.getTransaction();

     //   Ticket sample = new Ticket("JavaDev", "Incident", "SysAdmin", LocalDate.of(2019, 02, 15),
      //          "404: Page not found. Restart services.", LocalDate.of(2019, 02, 20), "P2");
        
     //   Ticket sample = new Ticket(1L, "Incident", 2L, java.sql.Date.valueOf(LocalDate.of(2019, 04, 01)), java.sql.Date.valueOf(LocalDate.of(2019, 04, 01)), "Page not found", "404: Page not found. Restart services.", "P2");
     //   Ticket sample = new Ticket(3l, "Incident", 5l, LocalDate.of(2019,03,20),  LocalDate.of(2019,04,10), "404: Page not found. Restart services.", "Page not found", "P2","Open");
    //    tx.begin();
     //   em.persist(sample);
      //  tx.commit();
    }

    @After
    public void afterEachTestFixture() {

        Ticket sample = em.createNamedQuery("Ticket.findByOwner", Ticket.class).setParameter("ticketCreatedById", 3l).getSingleResult();
        tx.begin();
        em.remove(sample);
        tx.commit();
        
        if (em != null) {
            em.close();
        }
    }

    @AfterClass
    public static void afterClassTestFixturePerClass() {

        emf.close();
    }
}
